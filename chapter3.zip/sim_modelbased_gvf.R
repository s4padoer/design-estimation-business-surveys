#################################################
# Scenarios for GVF in a model-based population #
#################################################
iter <- as.integer( Sys.getenv("var") )
library(survey)
source("varfu.R")

R                     <- 15 # Number of MC replications 

N                     <- 1e4 # Population size
n                     <- 240 # Sample size

Nsubset               <- 25 # Number of subset that build a partition

param_pois            <- c(6, 24)
param_gamma           <- matrix( c(3, 2, 8, 3), ncol = 2 )
rownames(param_gamma) <- c("shape", "scale")

nvars                 <- 50

set.seed(1)
prob                  <- cumsum(1:Nsubset) 
prob                  <- prob/sum(prob)
strata                <- sample(Nsubset, size = N, replace = TRUE, prob = prob)
strata2               <- sapply(strata, function(x) ifelse( x < 6, 1, ifelse(x < 11, 2, ifelse(x < 16, 3, ifelse(x < 21, 4, 5)))))
Nh                    <- table(strata)
L                     <- tapply(strata, strata2, function(x) length(unique(x)))
Nstrat                <- tapply(Nh, rep(1:5, each = 5), sum) 
nh                    <- ceiling(Nh/N * n)  
n                     <- sum(nh)
split.strat           <- split(1:N, strata)
id                    <- 1:N
w.srs                 <- rep( N/n, N)
w.strat               <- (Nh/nh)[as.character(strata)]
w.strat               <- as.numeric(w.strat)

###########
### SRS ###
###########

# Store estimates:
ht_gamma1.srs         <- matrix(NA, nrow = R, ncol = nvars)
ht_gamma2.srs         <- matrix(NA, nrow = R, ncol = nvars)
ht_pois1.srs          <- matrix(NA, nrow = R, ncol = nvars)
ht_pois2.srs          <- matrix(NA, nrow = R, ncol = nvars)

# Direct variance estimates:
direct_var_gamma1.srs <- matrix(NA, nrow = R, ncol = nvars)
direct_var_gamma2.srs <- matrix(NA, nrow = R, ncol = nvars)
direct_var_pois1.srs  <- matrix(NA, nrow = R, ncol = nvars)
direct_var_pois2.srs  <- matrix(NA, nrow = R, ncol = nvars)

# Resampling variance estimates:
rep_var_gamma1.srs    <- matrix(NA, nrow = R, ncol = nvars)
rep_var_gamma2.srs    <- matrix(NA, nrow = R, ncol = nvars)
rep_var_pois1.srs     <- matrix(NA, nrow = R, ncol = nvars)
rep_var_pois2.srs     <- matrix(NA, nrow = R, ncol = nvars)

# GVF variance estimates:
gvf_mod1_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod3_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1w_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2w_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod3w_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4w_all_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1_ind_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2_ind_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4_ind_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1w_ind_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2w_ind_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4w_ind_var_gamma1.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_gamma2.srs   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_pois1.srs    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_pois2.srs    <- matrix(NA, nrow = R, ncol = nvars)

gersh_direct.srs        <- rep(NA, R)
gersh_mod1_all.srs      <- rep(NA, R)
gersh_mod1w_all.srs     <- rep(NA, R)
gersh_mod1_ind.srs      <- rep(NA, R)
gersh_mod1w_ind.srs     <- rep(NA, R)

gersh_mod2_all.srs      <- rep(NA, R)
gersh_mod2w_all.srs     <- rep(NA, R)
gersh_mod2_ind.srs      <- rep(NA, R)
gersh_mod2w_ind.srs     <- rep(NA, R)

gersh_mod3_all.srs      <- rep(NA, R)
gersh_mod3w_all.srs     <- rep(NA, R)

gersh_mod4_all.srs      <- rep(NA, R)
gersh_mod4w_all.srs     <- rep(NA, R)
gersh_mod4_ind.srs      <- rep(NA, R)
gersh_mod4w_ind.srs     <- rep(NA, R)

r2_mod1_all.srs      <- rep(NA, R)
r2_mod1w_all.srs     <- rep(NA, R)
r2_mod1_ind.srs      <- rep(NA, R)
r2_mod1w_ind.srs     <- rep(NA, R)

r2_mod2_all.srs      <- rep(NA, R)
r2_mod2w_all.srs     <- rep(NA, R)
r2_mod2_ind.srs      <- rep(NA, R)
r2_mod2w_ind.srs     <- rep(NA, R)

r2_mod4_all.srs      <- rep(NA, R)
r2_mod4w_all.srs     <- rep(NA, R)
r2_mod4_ind.srs      <- rep(NA, R)
r2_mod4w_ind.srs     <- rep(NA, R)

#############
### Strat ###
#############

# Store estimates:
ht_gamma1.strat         <- matrix(NA, nrow = R, ncol = nvars)
ht_gamma2.strat         <- matrix(NA, nrow = R, ncol = nvars)
ht_pois1.strat          <- matrix(NA, nrow = R, ncol = nvars)
ht_pois2.strat          <- matrix(NA, nrow = R, ncol = nvars)

# Direct variance estimates:
direct_var_gamma1.strat <- matrix(NA, nrow = R, ncol = nvars)
direct_var_gamma2.strat <- matrix(NA, nrow = R, ncol = nvars)
direct_var_pois1.strat  <- matrix(NA, nrow = R, ncol = nvars)
direct_var_pois2.strat  <- matrix(NA, nrow = R, ncol = nvars)

# Resampling variance estimates:
rep_var_gamma1.strat    <- matrix(NA, nrow = R, ncol = nvars)
rep_var_gamma2.strat    <- matrix(NA, nrow = R, ncol = nvars)
rep_var_pois1.strat     <- matrix(NA, nrow = R, ncol = nvars)
rep_var_pois2.strat     <- matrix(NA, nrow = R, ncol = nvars)

# GVF variance estimates:
gvf_mod1_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod3_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1w_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2w_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod3w_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4w_all_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1_ind_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2_ind_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4_ind_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1w_ind_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2w_ind_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4w_ind_var_gamma1.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_gamma2.strat   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_pois1.strat    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_pois2.strat    <- matrix(NA, nrow = R, ncol = nvars)

gersh_direct.strat        <- rep(NA, R)
gersh_mod1_all.strat      <- rep(NA, R)
gersh_mod1w_all.strat     <- rep(NA, R)
gersh_mod1_ind.strat      <- rep(NA, R)
gersh_mod1w_ind.strat     <- rep(NA, R)

gersh_mod2_all.strat      <- rep(NA, R)
gersh_mod2w_all.strat     <- rep(NA, R)
gersh_mod2_ind.strat      <- rep(NA, R)
gersh_mod2w_ind.strat     <- rep(NA, R)

gersh_mod3_all.strat      <- rep(NA, R)
gersh_mod3w_all.strat     <- rep(NA, R)

gersh_mod4_all.strat      <- rep(NA, R)
gersh_mod4w_all.strat     <- rep(NA, R)
gersh_mod4_ind.strat      <- rep(NA, R)
gersh_mod4w_ind.strat     <- rep(NA, R)

r2_mod1_all.strat      <- rep(NA, R)
r2_mod1w_all.strat     <- rep(NA, R)
r2_mod1_ind.strat      <- rep(NA, R)
r2_mod1w_ind.strat     <- rep(NA, R)

r2_mod2_all.strat      <- rep(NA, R)
r2_mod2w_all.strat     <- rep(NA, R)
r2_mod2_ind.strat      <- rep(NA, R)
r2_mod2w_ind.strat     <- rep(NA, R)

r2_mod4_all.strat      <- rep(NA, R)
r2_mod4w_all.strat     <- rep(NA, R)
r2_mod4_ind.strat      <- rep(NA, R)
r2_mod4w_ind.strat     <- rep(NA, R)

###########
### TSC ###
###########

# Store estimates:
ht_gamma1.tsc         <- matrix(NA, nrow = R, ncol = nvars)
ht_gamma2.tsc         <- matrix(NA, nrow = R, ncol = nvars)
ht_pois1.tsc          <- matrix(NA, nrow = R, ncol = nvars)
ht_pois2.tsc          <- matrix(NA, nrow = R, ncol = nvars)

# Direct variance estimates:
direct_var_gamma1.tsc <- matrix(NA, nrow = R, ncol = nvars)
direct_var_gamma2.tsc <- matrix(NA, nrow = R, ncol = nvars)
direct_var_pois1.tsc  <- matrix(NA, nrow = R, ncol = nvars)
direct_var_pois2.tsc  <- matrix(NA, nrow = R, ncol = nvars)

# Resampling variance estimates:
rep_var_gamma1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
rep_var_gamma2.tsc    <- matrix(NA, nrow = R, ncol = nvars)
rep_var_pois1.tsc     <- matrix(NA, nrow = R, ncol = nvars)
rep_var_pois2.tsc     <- matrix(NA, nrow = R, ncol = nvars)

# GVF variance estimates:
gvf_mod1_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod3_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1w_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2w_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod3w_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod3w_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4w_all_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_all_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1_ind_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1_ind_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2_ind_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2_ind_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4_ind_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4_ind_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod1w_ind_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod1w_ind_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod2w_ind_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod2w_ind_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gvf_mod4w_ind_var_gamma1.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_gamma2.tsc   <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_pois1.tsc    <- matrix(NA, nrow = R, ncol = nvars)
gvf_mod4w_ind_var_pois2.tsc    <- matrix(NA, nrow = R, ncol = nvars)

gersh_direct.tsc        <- rep(NA, R)
gersh_mod1_all.tsc      <- rep(NA, R)
gersh_mod1w_all.tsc     <- rep(NA, R)
gersh_mod1_ind.tsc      <- rep(NA, R)
gersh_mod1w_ind.tsc     <- rep(NA, R)

gersh_mod2_all.tsc      <- rep(NA, R)
gersh_mod2w_all.tsc     <- rep(NA, R)
gersh_mod2_ind.tsc      <- rep(NA, R)
gersh_mod2w_ind.tsc     <- rep(NA, R)

gersh_mod3_all.tsc      <- rep(NA, R)
gersh_mod3w_all.tsc     <- rep(NA, R)

gersh_mod4_all.tsc      <- rep(NA, R)
gersh_mod4w_all.tsc     <- rep(NA, R)
gersh_mod4_ind.tsc      <- rep(NA, R)
gersh_mod4w_ind.tsc     <- rep(NA, R)

r2_mod1_all.tsc      <- rep(NA, R)
r2_mod1w_all.tsc     <- rep(NA, R)
r2_mod1_ind.tsc      <- rep(NA, R)
r2_mod1w_ind.tsc     <- rep(NA, R)

r2_mod2_all.tsc      <- rep(NA, R)
r2_mod2w_all.tsc     <- rep(NA, R)
r2_mod2_ind.tsc      <- rep(NA, R)
r2_mod2w_ind.tsc     <- rep(NA, R)

r2_mod4_all.tsc      <- rep(NA, R)
r2_mod4w_all.tsc     <- rep(NA, R)
r2_mod4_ind.tsc      <- rep(NA, R)
r2_mod4w_ind.tsc     <- rep(NA, R)

#####################
set.seed(iter)
z <- qnorm(0.975)

for( r in 1:R){
  # Determine the training variablesj = 1,...200, where from each of the 4 distribution types we draw 
  # the same number of variables
  Q <- sapply( split(1:200, rep(1:4, each = 50)), sample, size = 5, replace = FALSE )
  Q <- c(Q)
  
  # Generate Data in finite population
  mat_gamma1 <- matrix( rgamma(N*nvars, shape = param_gamma[1,1], scale = param_gamma[2,1]), ncol = nvars )
  mat_gamma2 <- matrix( rgamma(N*nvars, shape = param_gamma[1,2], scale = param_gamma[2,2]), ncol = nvars )
  mat_pois1  <- matrix( rpois(N*nvars, lambda = param_pois[1]), ncol = nvars )
  mat_pois2  <- matrix( rpois(N*nvars, lambda = param_pois[2]), ncol = nvars )
  
  df         <- data.frame( id = id, w.srs = w.srs, w.strat = as.numeric(w.strat), 
                            strata = strata, strata2 = strata2,
                            cbind( mat_gamma1, mat_gamma2, mat_pois1, mat_pois2) )
  
  # Sampling from finite population
  # SRS
  samp.srs   <- sample(N, size = n, replace = FALSE)
  # StratRS
  samp.strat <- sapply( 1:length(nh), function(i) sample(split.strat[[i]], size = nh[i], replace = FALSE) )
  samp.strat <- unlist(samp.strat)
  # TSC
  # Equal allocation across strata
  # First stage: SRS (2/5)
  # Second stage: Take 30 Percent of PSU:
  samp.psu  <- tapply(1:Nsubset, rep(1:5, each = 5), function(x) sort( sample(x, size = 2, replace = FALSE) ) )
  samp.ssu  <- lapply(samp.psu, function(idpsu){ 
    out <- lapply(idpsu, function(x){
      nsize <- 0.3 * sum(strata == x)
      nsize <- (runif(1) <  nsize %% 1) + nsize %/% 1
      nsize <- max( c(nsize,1))
      ids <- sort( sample( x = id[strata == x], size = nsize, replace = FALSE ) )
      return( cbind(ids, sum(strata == x) / nsize * 5/2) ) } ) 
    out <- do.call(rbind, out)
    return(out)
    } )
  samp.ssu <- do.call(rbind, samp.ssu)
  
  # Point estimation (Horvitz-Thompson):
  ht_gamma1.srs[r,] <- colSums(mat_gamma1[samp.srs,] * w.srs[samp.srs])
  ht_gamma2.srs[r,] <- colSums(mat_gamma2[samp.srs,] * w.srs[samp.srs])
  ht_pois1.srs[r,]  <- colSums(mat_pois1[samp.srs,] * w.srs[samp.srs])
  ht_pois2.srs[r,]  <- colSums(mat_pois2[samp.srs,] * w.srs[samp.srs])
  
  # Balanced half-sample based alternative point estimator for standardization in function bhs_srs (Gershunskaya and Dorfman, 2013)
  gersh_ind <- c( bhs_srs(mat_gamma1[samp.srs,], w.srs[samp.srs]),
                  bhs_srs(mat_gamma2[samp.srs,], w.srs[samp.srs]),
                  bhs_srs(mat_pois1[samp.srs,], w.srs[samp.srs]),
                  bhs_srs(mat_pois2[samp.srs,], w.srs[samp.srs]) )
  
  # Direct variance estimator for HT:
  direct_var_gamma1.srs[r,] <- apply(mat_gamma1[samp.srs,], 2, var.srs, w = w.srs[samp.srs])
  direct_var_gamma2.srs[r,] <- apply(mat_gamma2[samp.srs,], 2, var.srs, w = w.srs[samp.srs])
  direct_var_pois1.srs[r,]  <- apply(mat_pois1[samp.srs,], 2,  var.srs, w = w.srs[samp.srs])
  direct_var_pois2.srs[r,]  <- apply(mat_pois2[samp.srs,], 2,  var.srs, w = w.srs[samp.srs])
  
  hv <- gersh_ind / sqrt( c(direct_var_gamma1.srs[r,], direct_var_gamma2.srs[r,], 
                            direct_var_pois1.srs[r,], direct_var_pois2.srs[r,]) )
  gersh_direct.srs[r] <- mean( hv <  z & hv > -z, na.rm = TRUE)
  
  # Replicate Weights & Variance
  des <- svydesign( ~ 1, fpc = rep(n/N, n), weights = w.srs[samp.srs], data = df[samp.srs, ])
  repw <- as.svrepdesign( des, type = "bootstrap" )
  out <- svytotal( as.formula( paste0( "~ ", paste( paste0("X", 1:200), collapse = " + ") ) ), repw )
  out <- SE(out)^2
  rep_var_gamma1.srs[r,] <- out[1:50]
  rep_var_gamma2.srs[r,] <- out[51:100]
  rep_var_pois1.srs[r,]  <- out[101:150]
  rep_var_pois2.srs[r,]  <- out[151:200]
  
  # GVFs
  vardf <- data.frame( pointest = c(ht_gamma1.srs[r,], ht_gamma2.srs[r,], ht_pois1.srs[r,], ht_pois2.srs[r,]),
                       varest   = c(direct_var_gamma1.srs[r,], direct_var_gamma2.srs[r,], direct_var_pois1.srs[r,], direct_var_pois2.srs[r,]),
                       indicator = as.factor(rep(1:4, each = 50)) )
  
  # mod1: logvar:
  mod1 <- lm( log(varest) ~ log(pointest), data = vardf[Q,] )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1_all_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod1_all_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod1_all_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod1_all_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod1_all.srs[r] <- summary(mod1)$r.squared
  gersh_mod1_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod1 <- lm( log(varest) ~ indicator*log(pointest), data = vardf[Q,] )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1_ind_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod1_ind_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod1_ind_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod1_ind_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod1_ind.srs[r] <- summary(mod1)$r.squared
  gersh_mod1_ind.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod1 <- lm( log(varest) ~ log(pointest), data = vardf[Q,], weights = w )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1w_all_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod1w_all_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod1w_all_var_pois1.srs[r,]  <- pred[101:150]
  gvf_mod1w_all_var_pois2.srs[r,]  <- pred[151:200]
  
  r2_mod1w_all.srs[r] <- summary(mod1)$r.squared
  gersh_mod1w_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod1 <- lm( log(varest) ~ indicator*log(pointest), data = vardf[Q,], weights = w )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1w_ind_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod1w_ind_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod1w_ind_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod1w_ind_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod1w_ind.srs[r] <- summary(mod1)$r.squared
  gersh_mod1w_ind.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z)
  
  # mod2: relvar:
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest) + I(1/pointest^2), data = vardf[Q,] )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2_all_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod2_all_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod2_all_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod2_all_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod2_all.srs[r] <- summary(mod2)$r.squared
  gersh_mod2_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest)*indicator + I(1/pointest^2)*indicator, data = vardf[Q,] )  
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2_ind_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod2_ind_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod2_ind_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod2_ind_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod2_ind.srs[r] <- summary(mod2)$r.squared
  gersh_mod2_ind.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest) + I(1/pointest^2), data = vardf[Q,], weights = w )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2w_all_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod2w_all_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod2w_all_var_pois1.srs[r,]  <- pred[101:150]
  gvf_mod2w_all_var_pois2.srs[r,]  <- pred[151:200]
  
  r2_mod2w_all.srs[r] <- summary(mod2)$r.squared
  gersh_mod2w_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest)*indicator + I(1/pointest^2)*indicator, data = vardf[Q,], weights = w )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2w_ind_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod2w_ind_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod2w_ind_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod2w_ind_var_pois2.srs[r,] <- pred[151:200]
  
  gersh_mod2w_ind.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  # mod3: nonlinear regression
  mod3 <- try( nls( I(varest/pointest^2) ~ I(1/(a + b*pointest)), data = vardf[Q,], control = list(maxiter = 80) ), silent = TRUE )
  if(class(mod3) != "try-error"){
    pred <- predict(mod3, newdata = vardf) * vardf$pointest^2
    gvf_mod3_all_var_gamma1.srs[r,] <- pred[1:50]
    gvf_mod3_all_var_gamma2.srs[r,] <- pred[51:100]
    gvf_mod3_all_var_pois1.srs[r,] <- pred[101:150]
    gvf_mod3_all_var_pois2.srs[r,] <- pred[151:200]
    gersh_mod3_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  }
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod3 <- try( nls( I(varest/pointest^2) ~ I(1/(a + b*pointest)), data = vardf[Q,], control = list(maxiter = 80), weights = w ), silent = TRUE )
  if( class(mod3) != "try-error"){
    pred <- predict(mod3, newdata = vardf) * vardf$pointest^2
    gvf_mod3w_all_var_gamma1.srs[r,] <- pred[1:50]
    gvf_mod3w_all_var_gamma2.srs[r,] <- pred[51:100]
    gvf_mod3w_all_var_pois1.srs[r,]  <- pred[101:150]
    gvf_mod3w_all_var_pois2.srs[r,]  <- pred[151:200]
    gersh_mod3w_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  }

  # mod4: linear regression:
  mod4 <- lm( varest ~ pointest + I(pointest^2), data = vardf[Q,] )
  pred <- predict(mod4, newdata = vardf) 
  gvf_mod4_all_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod4_all_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod4_all_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod4_all_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod4_all.srs[r] <- summary(mod4)$r.squared
  gersh_mod4_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod4 <- lm( varest ~ pointest*indicator + I(pointest^2)*indicator, data = vardf[Q,] )  
  pred <- predict(mod4, newdata = vardf) 
  gvf_mod4_ind_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod4_ind_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod4_ind_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod4_ind_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod4_ind.srs[r] <- summary(mod4)$r.squared
  gersh_mod4_ind.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod4 <- lm( varest ~ pointest + I(pointest^2), data = vardf[Q,], weights = w )
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4w_all_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod4w_all_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod4w_all_var_pois1.srs[r,]  <- pred[101:150]
  gvf_mod4w_all_var_pois2.srs[r,]  <- pred[151:200]
  
  r2_mod4w_all.srs[r] <- summary(mod4)$r.squared
  gersh_mod4w_all.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod4 <- lm( varest ~ pointest*indicator + I(pointest^2)*indicator, data = vardf[Q,], weights = w )
  pred <- predict(mod4, newdata = vardf) 
  gvf_mod4w_ind_var_gamma1.srs[r,] <- pred[1:50]
  gvf_mod4w_ind_var_gamma2.srs[r,] <- pred[51:100]
  gvf_mod4w_ind_var_pois1.srs[r,] <- pred[101:150]
  gvf_mod4w_ind_var_pois2.srs[r,] <- pred[151:200]
  
  r2_mod4w_ind.srs[r] <- summary(mod4)$r.squared
  gersh_mod4w_ind.srs[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  ###############
  # Strat
  # Point estimation (Horvitz Thompson):
  ht_gamma1.strat[r,] <- colSums(mat_gamma1[samp.strat,] * w.strat[samp.strat])
  ht_gamma2.strat[r,] <- colSums(mat_gamma2[samp.strat,] * w.strat[samp.strat])
  ht_pois1.strat[r,]  <- colSums(mat_pois1[samp.strat,] * w.strat[samp.strat])
  ht_pois2.strat[r,]  <- colSums(mat_pois2[samp.strat,] * w.strat[samp.strat])
  
  # Balanced half-sample based alternative point estimator for standardization in function bhs_srs (Gershunskaya and Dorfman, 2013)
  gersh_ind <- c( bhs_strat(mat_gamma1[samp.strat,], w.strat[samp.strat], strata = strata[samp.strat]),
                  bhs_strat(mat_gamma2[samp.strat,], w.strat[samp.strat], strata = strata[samp.strat]),
                  bhs_strat(mat_pois1[samp.strat,], w.strat[samp.strat], strata = strata[samp.strat]),
                  bhs_strat(mat_pois2[samp.strat,], w.strat[samp.strat], strata = strata[samp.strat]) )
  
  # Direct variance estimator:
  direct_var_gamma1.strat[r,] <- apply(mat_gamma1[samp.strat,], 2, var.strat, w = w.strat[samp.strat], strat = strata[samp.strat] )
  direct_var_gamma2.strat[r,] <- apply(mat_gamma2[samp.strat,], 2, var.strat, w = w.strat[samp.strat], strat = strata[samp.strat] )
  direct_var_pois1.strat[r,]  <- apply(mat_pois1[samp.strat,], 2,  var.strat, w = w.strat[samp.strat], strat = strata[samp.strat] )
  direct_var_pois2.strat[r,]  <- apply(mat_pois2[samp.strat,], 2,  var.strat, w = w.strat[samp.strat], strat = strata[samp.strat] )
  
  hv <- gersh_ind / sqrt( c(direct_var_gamma1.strat[r,], direct_var_gamma2.strat[r,], 
                            direct_var_pois1.strat[r,], direct_var_pois2.strat[r,]) )
  gersh_direct.strat[r] <- mean( hv <  z & hv > -z, na.rm = TRUE)
  
  # Replicate Weights & Variance
  des <- svydesign( ~ 1, strata = strata[samp.strat], fpc = 1/w.strat[samp.strat], weights = w.strat[samp.strat], data = df[samp.strat, ])
  repw <- as.svrepdesign( des, type = "bootstrap" )
  out <- svytotal( as.formula( paste0( "~ ", paste( paste0("X", 1:200), collapse = " + ") ) ), repw )
  out <- SE(out)^2
  rep_var_gamma1.strat[r,] <- out[1:50]
  rep_var_gamma2.strat[r,] <- out[51:100]
  rep_var_pois1.strat[r,]  <- out[101:150]
  rep_var_pois2.strat[r,]  <- out[151:200]
  
  # GVFs
  vardf <- data.frame( pointest = c(ht_gamma1.strat[r,], ht_gamma2.strat[r,], ht_pois1.strat[r,], ht_pois2.strat[r,]),
                       varest   = c(direct_var_gamma1.strat[r,], direct_var_gamma2.strat[r,], direct_var_pois1.strat[r,], direct_var_pois2.strat[r,]),
                       indicator = as.factor(rep(1:4, each = 50)) )
  
  # mod1: logvar:
  mod1 <- lm( log(varest) ~ log(pointest), data = vardf[Q,] )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1_all_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod1_all_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod1_all_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod1_all_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod1_all.strat[r] <- summary(mod1)$r.squared
  gersh_mod1_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod1 <- lm( log(varest) ~ indicator*log(pointest), data = vardf[Q,] )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1_ind_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod1_ind_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod1_ind_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod1_ind_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod1_ind.strat[r] <- summary(mod1)$r.squared
  gersh_mod1_ind.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod1 <- lm( log(varest) ~ log(pointest), data = vardf[Q,], weights = w )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1w_all_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod1w_all_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod1w_all_var_pois1.strat[r,]  <- pred[101:150]
  gvf_mod1w_all_var_pois2.strat[r,]  <- pred[151:200]
  
  r2_mod1w_all.strat[r] <- summary(mod1)$r.squared
  gersh_mod1w_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z)
  
  mod1 <- lm( log(varest) ~ indicator*log(pointest), data = vardf[Q,], weights = w )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1w_ind_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod1w_ind_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod1w_ind_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod1w_ind_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod1w_ind.strat[r] <- summary(mod1)$r.squared
  gersh_mod1w_ind.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z)
  
  # mod2: relvar:
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest) + I(1/pointest^2), data = vardf[Q,] )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2_all_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod2_all_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod2_all_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod2_all_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod2_all.strat[r] <- summary(mod2)$r.squared
  gersh_mod2_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest)*indicator + I(1/pointest^2)*indicator, data = vardf[Q,] )  
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2_ind_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod2_ind_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod2_ind_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod2_ind_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod2_ind.strat[r] <- summary(mod2)$r.squared
  gersh_mod2_ind.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest) + I(1/pointest^2), data = vardf[Q,], weights = w )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2w_all_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod2w_all_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod2w_all_var_pois1.strat[r,]  <- pred[101:150]
  gvf_mod2w_all_var_pois2.strat[r,]  <- pred[151:200]
  
  r2_mod2w_all.strat[r] <- summary(mod2)$r.squared
  gersh_mod2w_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest)*indicator + I(1/pointest^2)*indicator, data = vardf[Q,], weights = w )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2w_ind_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod2w_ind_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod2w_ind_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod2w_ind_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod2w_ind.strat[r] <- summary(mod2)$r.squared
  gersh_mod2w_ind.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  # mod3: nonlinear regression
  mod3 <- try( nls( I(varest/pointest^2) ~ I(1/(a + b*pointest)), data = vardf[Q,], control = list(maxiter = 80) ), silent = TRUE )
  if(class(mod3) != "try-error"){
    pred <- predict(mod3, newdata = vardf) * vardf$pointest^2
    gvf_mod3_all_var_gamma1.strat[r,] <- pred[1:50]
    gvf_mod3_all_var_gamma2.strat[r,] <- pred[51:100]
    gvf_mod3_all_var_pois1.strat[r,] <- pred[101:150]
    gvf_mod3_all_var_pois2.strat[r,] <- pred[151:200] 
    gersh_mod3_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  }
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod3 <- try( nls( I(varest/pointest^2) ~ I(1/(a + b*pointest)), data = vardf[Q,], control = list(maxiter = 80), weights = w ), silent = TRUE )
  if(class(mod3) != "try-error"){
    pred <- predict(mod3, newdata = vardf) * vardf$pointest^2
    gvf_mod3w_all_var_gamma1.strat[r,] <- pred[1:50]
    gvf_mod3w_all_var_gamma2.strat[r,] <- pred[51:100]
    gvf_mod3w_all_var_pois1.strat[r,]  <- pred[101:150]
    gvf_mod3w_all_var_pois2.strat[r,]  <- pred[151:200] 
    gersh_mod3w_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  }
  
  # mod4: linear regression:
  mod4 <- lm( varest ~ pointest + I(pointest^2), data = vardf[Q,] )
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4_all_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod4_all_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod4_all_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod4_all_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod4_all.strat[r] <- summary(mod4)$r.squared
  gersh_mod4_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod4 <- lm( varest ~ pointest*indicator + I(pointest^2)*indicator, data = vardf[Q,] )  
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4_ind_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod4_ind_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod4_ind_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod4_ind_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod4_ind.strat[r] <- summary(mod4)$r.squared
  gersh_mod4_ind.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod4 <- lm( varest ~ pointest + I(pointest^2), data = vardf[Q,], weights = w )
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4w_all_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod4w_all_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod4w_all_var_pois1.strat[r,]  <- pred[101:150]
  gvf_mod4w_all_var_pois2.strat[r,]  <- pred[151:200]
  
  r2_mod4w_all.strat[r] <- summary(mod4)$r.squared
  gersh_mod4w_all.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod4 <- lm( varest ~ pointest*indicator + I(pointest^2)*indicator, data = vardf[Q,], weights = w )
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4w_ind_var_gamma1.strat[r,] <- pred[1:50]
  gvf_mod4w_ind_var_gamma2.strat[r,] <- pred[51:100]
  gvf_mod4w_ind_var_pois1.strat[r,] <- pred[101:150]
  gvf_mod4w_ind_var_pois2.strat[r,] <- pred[151:200]
  
  r2_mod4w_ind.strat[r] <- summary(mod4)$r.squared
  gersh_mod4w_ind.strat[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  ###############
  # TSC
  w.tsc    <- samp.ssu[,2]
  samp.tsc <- samp.ssu[,1]

  dfsamp <- df[samp.tsc,]
  dfsamp$w.tsc <- w.tsc
  dfsamp$fpc1 <- 2/5
  dfsamp$fpc2 <- 1/(w.tsc * 5/2)
  
  # Point estimation (Horvitz Thompson):
  ht_gamma1.tsc[r,] <- colSums(mat_gamma1[samp.tsc,] * w.tsc)
  ht_gamma2.tsc[r,] <- colSums(mat_gamma2[samp.tsc,] * w.tsc)
  ht_pois1.tsc[r,]  <- colSums(mat_pois1[samp.tsc,] * w.tsc)
  ht_pois2.tsc[r,]  <- colSums(mat_pois2[samp.tsc,] * w.tsc)
  
  # Direct variance estimator for HT:
  direct_var_gamma1.tsc[r,] <- apply(as.matrix(dfsamp[,c(paste0("X", 1:50))]), 2, var.strattsc, w = dfsamp$w.tsc, strat = dfsamp$strata2, psu = dfsamp$strata, L = L, NL = Nh, Nstrat = Nstrat )
  direct_var_gamma2.tsc[r,] <- apply(as.matrix(dfsamp[,c(paste0("X", 51:100))]), 2, var.strattsc, w = dfsamp$w.tsc, strat = dfsamp$strata2, psu = dfsamp$strata, L = L, NL = Nh, Nstrat = Nstrat )
  direct_var_pois1.tsc[r,]  <- apply(as.matrix(dfsamp[,c(paste0("X", 101:150))]), 2, var.strattsc, w = dfsamp$w.tsc, strat = dfsamp$strata2, psu = dfsamp$strata, L = L, NL = Nh, Nstrat = Nstrat )
  direct_var_pois2.tsc[r,]  <- apply(as.matrix(dfsamp[,c(paste0("X", 151:200))]), 2, var.strattsc, w = dfsamp$w.tsc, strat = dfsamp$strata2, psu = dfsamp$strata, L = L, NL = Nh, Nstrat = Nstrat )
  
  # Balanced half-sample based alternative point estimator for standardization in function bhs_srs (Gershunskaya and Dorfman, 2013)
  gersh_ind <- c( bhs_strattsc(mat_gamma1[samp.tsc,], w.strat[samp.tsc], strata = strata2[samp.tsc], psu = strata[samp.tsc]),
                  bhs_strattsc(mat_gamma2[samp.tsc,], w.strat[samp.tsc], strata = strata2[samp.tsc], psu = strata[samp.tsc]),
                  bhs_strattsc(mat_pois1[samp.tsc,], w.strat[samp.tsc], strata = strata2[samp.tsc], psu = strata[samp.tsc]),
                  bhs_strattsc(mat_pois2[samp.tsc,], w.strat[samp.tsc], strata = strata2[samp.tsc], psu = strata[samp.tsc]) )
  
  hv <- gersh_ind / sqrt( c(direct_var_gamma1.tsc[r,], direct_var_gamma2.tsc[r,], 
                            direct_var_pois1.tsc[r,], direct_var_pois2.tsc[r,]) )
  gersh_direct.tsc[r] <- mean( hv <  z & hv > -z, na.rm = TRUE)
  
  # Replicate Weights & Variance
  des <- svydesign( id = ~ strata, strata = ~strata2, fpc = ~ fpc1, weights = w.tsc, data = dfsamp)
  repw <- as.svrepdesign( des, type = "bootstrap" )
  out <- svytotal( as.formula( paste0( "~ ", paste( paste0("X", 1:200), collapse = " + ") ) ), repw )
  out <- SE(out)^2
  rep_var_gamma1.tsc[r,] <- out[1:50]
  rep_var_gamma2.tsc[r,] <- out[51:100]
  rep_var_pois1.tsc[r,]  <- out[101:150]
  rep_var_pois2.tsc[r,]  <- out[151:200]
  
  # GVFs
  vardf <- data.frame( pointest = c(ht_gamma1.tsc[r,], ht_gamma2.tsc[r,], ht_pois1.tsc[r,], ht_pois2.tsc[r,]),
                       varest   = c(direct_var_gamma1.tsc[r,], direct_var_gamma2.tsc[r,], direct_var_pois1.tsc[r,], direct_var_pois2.tsc[r,]),
                       indicator = as.factor(rep(1:4, each = 50)) )
  
  # mod1: logvar:
  mod1 <- lm( log(varest) ~ log(pointest), data = vardf[Q,] )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1_all_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod1_all_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod1_all_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod1_all_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod1_all.tsc[r] <- summary(mod1)$r.squared
  gersh_mod1_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod1 <- lm( log(varest) ~ indicator*log(pointest), data = vardf[Q,] )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1_ind_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod1_ind_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod1_ind_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod1_ind_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod1_ind.tsc[r] <- summary(mod1)$r.squared
  gersh_mod1_ind.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod1 <- lm( log(varest) ~ log(pointest), data = vardf[Q,], weights = w )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1w_all_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod1w_all_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod1w_all_var_pois1.tsc[r,]  <- pred[101:150]
  gvf_mod1w_all_var_pois2.tsc[r,]  <- pred[151:200]
  
  r2_mod1w_all.tsc[r] <- summary(mod1)$r.squared
  gersh_mod1w_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod1 <- lm( log(varest) ~ indicator*log(pointest), data = vardf[Q,], weights = w )
  pred <- exp( predict(mod1, newdata = vardf) ) * exp(0.5*summary(mod1)$sigma^2)
  gvf_mod1w_ind_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod1w_ind_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod1w_ind_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod1w_ind_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod1w_ind.tsc[r] <- summary(mod1)$r.squared
  gersh_mod1w_ind.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  # mod2: relvar:
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest) + I(1/pointest^2), data = vardf[Q,] )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2_all_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod2_all_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod2_all_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod2_all_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod2_all.tsc[r] <- summary(mod2)$r.squared
  gersh_mod2_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest)*indicator + I(1/pointest^2)*indicator, data = vardf[Q,] )  
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2_ind_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod2_ind_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod2_ind_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod2_ind_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod2_ind.tsc[r] <- summary(mod2)$r.squared
  gersh_mod2_ind.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest) + I(1/pointest^2), data = vardf[Q,], weights = w )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2w_all_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod2w_all_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod2w_all_var_pois1.tsc[r,]  <- pred[101:150]
  gvf_mod2w_all_var_pois2.tsc[r,]  <- pred[151:200]
  
  r2_mod2w_all.tsc[r] <- summary(mod2)$r.squared
  gersh_mod2w_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod2 <- lm( I(varest/pointest^2) ~ I(1/pointest)*indicator + I(1/pointest^2)*indicator, data = vardf[Q,], weights = w )
  pred <- predict(mod2, newdata = vardf) * vardf$pointest^2
  gvf_mod2w_ind_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod2w_ind_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod2w_ind_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod2w_ind_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod2w_ind.tsc[r] <- summary(mod2)$r.squared
  gersh_mod2w_ind.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  # mod3: nonlinear regression
  mod3 <- try( nls( I(varest/pointest^2) ~ I(1/(a + b*pointest)), data = vardf[Q,], control = list(maxiter = 80) ), silent = TRUE )
  if(class(mod3) != "try-error"){
    pred <- predict(mod3, newdata = vardf) * vardf$pointest^2
    gvf_mod3_all_var_gamma1.tsc[r,] <- pred[1:50]
    gvf_mod3_all_var_gamma2.tsc[r,] <- pred[51:100]
    gvf_mod3_all_var_pois1.tsc[r,] <- pred[101:150]
    gvf_mod3_all_var_pois2.tsc[r,] <- pred[151:200]
    gersh_mod3_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  }

  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod3 <- try( nls( I(varest/pointest^2) ~ I(1/(a + b*pointest)), data = vardf[Q,], control = list(maxiter = 80), weights = w ), silent = TRUE )
  if(class(mod3) != "try-error"){
    pred <- predict(mod3, newdata = vardf) * vardf$pointest^2
    gvf_mod3w_all_var_gamma1.tsc[r,] <- pred[1:50]
    gvf_mod3w_all_var_gamma2.tsc[r,] <- pred[51:100]
    gvf_mod3w_all_var_pois1.tsc[r,]  <- pred[101:150]
    gvf_mod3w_all_var_pois2.tsc[r,]  <- pred[151:200]
    gersh_mod3w_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  }
  
  # mod4: linear regression:
  mod4 <- lm( varest ~ pointest + I(pointest^2), data = vardf[Q,] )
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4_all_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod4_all_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod4_all_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod4_all_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod4_all.tsc[r] <- summary(mod4)$r.squared
  gersh_mod4_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod4 <- lm( varest ~ pointest*indicator + I(pointest^2)*indicator, data = vardf[Q,] )  
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4_ind_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod4_ind_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod4_ind_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod4_ind_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod4_ind.tsc[r] <- summary(mod4)$r.squared
  gersh_mod4_ind.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  w <- (vardf$pointest[Q]^2/vardf$varest[Q])^2
  w <- w/sum(w)*length(w)
  
  mod4 <- lm( varest ~ pointest + I(pointest^2), data = vardf[Q,], weights = w )
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4w_all_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod4w_all_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod4w_all_var_pois1.tsc[r,]  <- pred[101:150]
  gvf_mod4w_all_var_pois2.tsc[r,]  <- pred[151:200]
  
  r2_mod4w_all.tsc[r] <- summary(mod4)$r.squared
  gersh_mod4w_all.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
  
  mod4 <- lm( varest ~ pointest*indicator + I(pointest^2)*indicator, data = vardf[Q,], weights = w )
  pred <- predict(mod4, newdata = vardf)
  gvf_mod4w_ind_var_gamma1.tsc[r,] <- pred[1:50]
  gvf_mod4w_ind_var_gamma2.tsc[r,] <- pred[51:100]
  gvf_mod4w_ind_var_pois1.tsc[r,] <- pred[101:150]
  gvf_mod4w_ind_var_pois2.tsc[r,] <- pred[151:200]
  
  r2_mod4w_ind.tsc[r] <- summary(mod4)$r.squared
  gersh_mod4w_ind.tsc[r] <- mean( gersh_ind/sqrt(pred) <  z & gersh_ind/sqrt(pred) > -z, na.rm = TRUE)
}

safe <- ls()[grepl("pois", ls()) | grepl("gamma", ls())]
safe <- c(safe, ls()[grepl("gersh", ls()) | grepl("r2", ls())])

for(x in safe){
  assign( paste0(x, "_sim", iter), get(x) )
}

save( list = paste0(safe, "_sim", iter), file = paste0("results/simulation_", iter, ".RData") )







