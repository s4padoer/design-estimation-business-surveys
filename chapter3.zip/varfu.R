# Variance Estimators for HT
# SRS
var.srs <- function(x, w){
  N <- sum(w)
  n <- length(w)
  return( var(x) * N^2/n * (1-n/N) )
}

# StratRS: Some strata must be merged because only one unit is sampled
var.strat <- function(x, w, strat){
  N <- tapply(w, strat, sum)
  n <- as.numeric( table(strat) )
  n[1] <- n[1] + n[2]
  n[3] <- n[3] + n[4]
  N[1] <- N[1] + N[2]
  N[3] <- N[3] + N[4]
  n <- n[-c(2,4)]
  N <- N[-c(2,4)]
  strat[strat == 2] <- 1
  strat[strat == 4] <- 3
  vars <- tapply(x, strat, var) * N^2/n * (1-n/N) 
  return( sum(vars) )
}

var.strattsc <- function(x, w, strat, psu, L, NL, Nstrat){
  # Merge those PSUs, where only one secondary sampling unit was drawn:
  psu.strat <- tapply(psu, strat, function(x) sort(unique(x)))
  l         <- tapply(psu, strat, function(x) length(unique(x)))
  nl        <- lapply(psu.strat,  function(x) table(psu[psu %in% x]) )
  if(any(unlist(nl) == 1)){
    # Merging of clusters yields one psu per stratum. Add thus the clusters to another stratum
    ind <- which( sapply(nl, function(ns) any(ns == 1)) )
    if(length(ind) == 1 && ind == 1){
      strat[strat == ind] <- strat[strat == ind] + 1
      }
    if(length(ind) == 1 && ind == 2){
      strat[strat == ind-1] <- strat[strat == ind]
    }
    if(length(ind) == 2){
      strat[strat %in% ind] <- min(strat[strat == ind])
    }
    L[2] <- L[2]+L[1]
    L <- L[-1]
    psu.strat <- tapply(psu, strat, function(x) sort(unique(x)))
    l         <- tapply(psu, strat, function(x) length(unique(x)))
    nl        <- lapply(psu.strat,  function(x) table(psu[psu %in% x]) )
    if(any(unlist(nl) == 1)){
      unl <- unlist(nl)
      unl2 <- sapply(nl, function(x) if(any(x == 1)) which.min(x[x > 1]))
      unl2 <- sapply( strsplit( names( unlist(unl2) ), ".", fixed = TRUE ), function(x) x[2] )
      ind <- sapply( strsplit( names(unl[unl == 1]), ".", fixed = TRUE), function(x) x[2])
      for(i in 1:length(ind)){
        psu[psu == as.integer(ind[i])] <- as.integer(unl2[i])
        NL[unl2[i]] <- NL[unl2[i]]+NL[ind[i]]
        NL <- NL[-which(names(NL) == ind[i])]
      }
      psu.strat <- tapply(psu, strat, function(x) sort(unique(x)))
      nl        <- lapply(psu.strat,  function(x) table(psu[psu %in% x]) )
    }
  }
  nam <- unlist( sapply(nl, function(x) names(x)) )
  nl <- unlist(nl)
  names(nl) <- nam
  var.ssu    <- tapply(x, psu, var) # Variance within clusters
  ht.ssu     <- tapply(x*w, psu, sum)/tapply(w, psu, sum) # Mean within clusters (sigma_q^2 in slides)
  strat_komp1 <- sapply(psu.strat, function(ind){
    ind <- as.character(ind)
    ret <- NL[ind]^2/as.numeric(nl[ind]) * (1 - as.numeric(nl[ind])/NL[ind]) * as.numeric(var.ssu[ind])
    return(sum(ret))
    }) * L/l # Variance of estimated cluster mean
  strat_komp2 <- sapply(1:length(psu.strat), function(i){
    ind <- psu.strat[[i]]
    ind <- as.character(ind)
    strattot <- sum( NL[ind]/Nstrat[i] * ht.ssu[ind]) * L[i] / length(ind)
    ret <- sum( (ht.ssu[ind]*NL[ind] -  Nstrat[i] * strattot / L[i])^2 ) / (length(ind)-1)
  }) * L^2/l * (1-l/L)
  out <- sum( strat_komp1 + strat_komp2 )
  return(out)
}

# For Gershunskaya's and Dorfman's Criterion (2013): One half-sample generation
bhs_srs <- function( matr, weights ){
  
  ht    <- colSums(matr * weights) 
  
  n     <- length(weights)
  nhalf <- round(0.5*n)
  ind   <- sample(n, size = nhalf, replace = FALSE)
  
  zga   <- rbind( colSums(matr[ind,] * weights[ind] * n/nhalf), 
                  colSums(matr[!ind,] * weights[!ind])*n/(n-nhalf) )
  zga   <- colSums( c(1.5, 0.5) * zga ) * 0.5
  zg    <- (zga - ht) / 0.5
  return(zg)
}

bhs_strat <- function( matr, weights, strata ){
  strata[strata == 2] <- 1
  strata[strata == 4] <- 3
  
  ht    <- colSums(matr * weights) 
  
  n     <- tapply( weights, strata, length )
  nhalf <- round(0.5*n)
  ind   <- mapply( function(id, ns) sample(x = id, size = ns, replace = FALSE), split(1:length(weights), strata), nhalf, SIMPLIFY = FALSE )
  notind <- mapply( function(all, id) return(all[!(all %in% id)]), split(1:length(weights), strata), ind, SIMPLIFY = FALSE)
  zga   <- rbind( rowSums( mapply( function(id, i) colSums( matrix( matr[id,], ncol = ncol(matr)) * weights[id]) * n[i]/nhalf[i], ind, 1:length(n)) ), 
                  rowSums( mapply( function(id, i) colSums( matrix( matr[id,], ncol = ncol(matr)) * weights[id]) * n[i]/(n[i] - nhalf[i]), notind, 1:length(n)) ) )
  zga   <- colSums( c(1.5, 0.5) * zga ) * 0.5
  zg    <- (zga - ht) / 0.5
  return(zg)
}

bhs_strattsc <- function( matr, weights, strata, psu ){
  
  ht    <- colSums(matr * weights) 
  
  n     <- tapply( psu, strata, function(x) length(unique(x)) )
  nhalf <- round(0.5*n)
  psustrat <- unique(cbind(psu,strata))
  ind   <- mapply( function(id, ns) sample(x = id, size = ns, replace = FALSE), split(psustrat[,1], psustrat[,2]), nhalf, SIMPLIFY = FALSE )
  notind <- mapply( function(all, id) return(all[!(all %in% id)]), split(psustrat[,1], psustrat[,2]), ind, SIMPLIFY = FALSE)
  zga   <- rbind( rowSums( mapply( function(id, i) colSums( matrix( matr[psu %in% id,], ncol = ncol(matr)) * weights[psu %in% id]) * n[i]/nhalf[i], ind, 1:length(n)) ), 
                  rowSums( mapply( function(id, i) colSums( matrix( matr[psu %in% id,], ncol = ncol(matr)) * weights[psu %in% id]) * n[i]/(n[i] - nhalf[i]), notind, 1:length(n)) ) )
  zga   <- colSums( c(1.5, 0.5) * zga ) * 0.5
  zg    <- (zga - ht) / 0.5
  return(zg)
}
