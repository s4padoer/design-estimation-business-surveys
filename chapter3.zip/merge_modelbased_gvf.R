##############################################
####### Merge the Simulation Results #########
##############################################

N                     <- 1e4 # Population size
n                     <- 253 # Sample size in SRS and StratRS

param_pois            <- c(6, 24)
param_gamma           <- matrix( c(3, 2, 8, 3), ncol = 2 )
rownames(param_gamma) <- c("shape", "scale")

path <- getwd()
setwd(path)

lf <- list.files( path = paste0(path, "/results") )

load( paste0(path, "/results/", lf[1]) )
sim  <- gsub("simulation_", "", lf[1])
sim  <- gsub(".RData", "", sim)
vars <- ls()[grepl( paste0("_sim", sim), ls() )]
vars <- gsub(paste0("_sim", sim), "", vars )

for(x in vars){
  assign(x, get(paste0(x, "_sim", sim)) )
}
rm( list = paste0(vars, "_sim", sim) )

for(y in lf[-1]){
  sim  <- gsub("simulation_", "", y)
  sim  <- gsub(".RData", "", sim)
  load( paste0(path, "/results/", y) )
  
  for(x in vars){
    hv <- get(paste0(x, "_sim", sim))
    assign(x, rbind(get(x), hv) )
  }
  rm( list = paste0(vars, "_sim", sim) )
  print(y)
}

# Monte-Carlo Variance of point estimators:
df.mc.var <- data.frame( mcvar = c( apply(ht_gamma1.srs, 2, var), apply(ht_gamma2.srs, 2, var), apply(ht_pois1.srs, 2, var), apply(ht_pois2.srs, 2, var),
                                    apply(ht_gamma1.strat, 2, var), apply(ht_gamma2.strat, 2, var), apply(ht_pois1.strat, 2, var), apply(ht_pois2.strat, 2, var),
                                    apply(ht_gamma1.tsc, 2, var), apply(ht_gamma2.tsc, 2, var), apply(ht_pois1.tsc, 2, var), apply(ht_pois2.tsc, 2, var) ),
                         variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                         design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

means <- aggregate( df.mc.var$mcvar, by = list(df.mc.var$variables, df.mc.var$design), mean )
cbind( means, "MC Variance of HT" = means$x * n/N, "expected model-design variance of HT" = rep(c(12, 48, 6, 24))*N) # (model variance times population size)


# Benchmarking with direct estimators:
df.direct.var <- data.frame( directvar = c( apply(direct_var_gamma1.srs, 2, mean), apply(direct_var_gamma2.srs, 2, mean), apply(direct_var_pois1.srs, 2, mean), apply(direct_var_pois2.srs, 2, mean),
                                    apply(direct_var_gamma1.strat, 2, mean), apply(direct_var_gamma2.strat, 2, mean), apply(direct_var_pois1.strat, 2, mean), apply(direct_var_pois2.strat, 2, mean),
                                    apply(direct_var_gamma1.tsc, 2, mean), apply(direct_var_gamma2.tsc, 2, mean), apply(direct_var_pois1.tsc, 2, mean), apply(direct_var_pois2.tsc, 2, mean) ),
                         variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                         design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

# Replicate weights
df.rep.var <- data.frame( repvar = c( apply(rep_var_gamma1.srs, 2, mean), apply(rep_var_gamma2.srs, 2, mean), apply(rep_var_pois1.srs, 2, mean), apply(rep_var_pois2.srs, 2, mean),
                                            apply(rep_var_gamma1.strat, 2, mean), apply(rep_var_gamma2.strat, 2, mean), apply(rep_var_pois1.strat, 2, mean), apply(rep_var_pois2.strat, 2, mean),
                                            apply(rep_var_gamma1.tsc, 2, mean), apply(rep_var_gamma2.tsc, 2, mean), apply(rep_var_pois1.tsc, 2, mean), apply(rep_var_pois2.tsc, 2, mean) ),
                             variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                             design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

#GVFs, mod1 version
df.mod1_all.var <- data.frame( gvf.pred = c( apply(gvf_mod1_all_var_gamma1.srs, 2, mean), apply(gvf_mod1_all_var_gamma2.srs, 2, mean), apply(gvf_mod1_all_var_pois1.srs, 2, mean), apply(gvf_mod1_all_var_pois2.srs, 2, mean),
                                           apply(gvf_mod1_all_var_gamma1.strat, 2, mean), apply(gvf_mod1_all_var_gamma2.strat, 2, mean), apply(gvf_mod1_all_var_pois1.strat, 2, mean), apply(gvf_mod1_all_var_pois2.strat, 2, mean),
                                           apply(gvf_mod1_all_var_gamma1.tsc, 2, mean), apply(gvf_mod1_all_var_gamma2.tsc, 2, mean), apply(gvf_mod1_all_var_pois1.tsc, 2, mean), apply(gvf_mod1_all_var_pois2.tsc, 2, mean) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod1w_all.var <- data.frame( gvf.pred = c( apply(gvf_mod1w_all_var_gamma1.srs, 2, mean), apply(gvf_mod1w_all_var_gamma2.srs, 2, mean), apply(gvf_mod1w_all_var_pois1.srs, 2, mean), apply(gvf_mod1w_all_var_pois2.srs, 2, mean),
                                           apply(gvf_mod1w_all_var_gamma1.strat, 2, mean), apply(gvf_mod1w_all_var_gamma2.strat, 2, mean), apply(gvf_mod1w_all_var_pois1.strat, 2, mean), apply(gvf_mod1w_all_var_pois2.strat, 2, mean),
                                           apply(gvf_mod1w_all_var_gamma1.tsc, 2, mean), apply(gvf_mod1w_all_var_gamma2.tsc, 2, mean), apply(gvf_mod1w_all_var_pois1.tsc, 2, mean), apply(gvf_mod1w_all_var_pois2.tsc, 2, mean) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod1_ind.var <- data.frame( gvf.pred = c( apply(gvf_mod1_ind_var_gamma1.srs, 2, mean), apply(gvf_mod1_ind_var_gamma2.srs, 2, mean), apply(gvf_mod1_ind_var_pois1.srs, 2, mean), apply(gvf_mod1_ind_var_pois2.srs, 2, mean),
                                           apply(gvf_mod1_ind_var_gamma1.strat, 2, mean), apply(gvf_mod1_ind_var_gamma2.strat, 2, mean), apply(gvf_mod1_ind_var_pois1.strat, 2, mean), apply(gvf_mod1_ind_var_pois2.strat, 2, mean),
                                           apply(gvf_mod1_ind_var_gamma1.tsc, 2, mean), apply(gvf_mod1_ind_var_gamma2.tsc, 2, mean), apply(gvf_mod1_ind_var_pois1.tsc, 2, mean), apply(gvf_mod1_ind_var_pois2.tsc, 2, mean) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )


df.mod1w_ind.var <- data.frame( gvf.pred = c( apply(gvf_mod1w_ind_var_gamma1.srs, 2, mean), apply(gvf_mod1w_ind_var_gamma2.srs, 2, mean), apply(gvf_mod1w_ind_var_pois1.srs, 2, mean), apply(gvf_mod1w_ind_var_pois2.srs, 2, mean),
                                            apply(gvf_mod1w_ind_var_gamma1.strat, 2, mean), apply(gvf_mod1w_ind_var_gamma2.strat, 2, mean), apply(gvf_mod1w_ind_var_pois1.strat, 2, mean), apply(gvf_mod1w_ind_var_pois2.strat, 2, mean),
                                            apply(gvf_mod1w_ind_var_gamma1.tsc, 2, mean), apply(gvf_mod1w_ind_var_gamma2.tsc, 2, mean), apply(gvf_mod1w_ind_var_pois1.tsc, 2, mean), apply(gvf_mod1w_ind_var_pois2.tsc, 2, mean) ),
                                variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                                design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

# GVFs mod2 version
df.mod2_all.var <- data.frame( gvf.pred = c( apply(gvf_mod2_all_var_gamma1.srs, 2, mean), apply(gvf_mod2_all_var_gamma2.srs, 2, mean), apply(gvf_mod2_all_var_pois1.srs, 2, mean), apply(gvf_mod2_all_var_pois2.srs, 2, mean),
                                           apply(gvf_mod2_all_var_gamma1.strat, 2, mean), apply(gvf_mod2_all_var_gamma2.strat, 2, mean), apply(gvf_mod2_all_var_pois1.strat, 2, mean), apply(gvf_mod2_all_var_pois2.strat, 2, mean),
                                           apply(gvf_mod2_all_var_gamma1.tsc, 2, mean), apply(gvf_mod2_all_var_gamma2.tsc, 2, mean), apply(gvf_mod2_all_var_pois1.tsc, 2, mean), apply(gvf_mod2_all_var_pois2.tsc, 2, mean) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod2w_all.var <- data.frame( gvf.pred = c( apply(gvf_mod2w_all_var_gamma1.srs, 2, mean), apply(gvf_mod2w_all_var_gamma2.srs, 2, mean), apply(gvf_mod2w_all_var_pois1.srs, 2, mean), apply(gvf_mod2w_all_var_pois2.srs, 2, mean),
                                            apply(gvf_mod2w_all_var_gamma1.strat, 2, mean), apply(gvf_mod2w_all_var_gamma2.strat, 2, mean), apply(gvf_mod2w_all_var_pois1.strat, 2, mean), apply(gvf_mod2w_all_var_pois2.strat, 2, mean),
                                            apply(gvf_mod2w_all_var_gamma1.tsc, 2, mean), apply(gvf_mod2w_all_var_gamma2.tsc, 2, mean), apply(gvf_mod2w_all_var_pois1.tsc, 2, mean), apply(gvf_mod2w_all_var_pois2.tsc, 2, mean) ),
                                variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                                design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod2_ind.var <- data.frame( gvf.pred = c( apply(gvf_mod2_ind_var_gamma1.srs, 2, mean), apply(gvf_mod2_ind_var_gamma2.srs, 2, mean), apply(gvf_mod2_ind_var_pois1.srs, 2, mean), apply(gvf_mod2_ind_var_pois2.srs, 2, mean),
                                           apply(gvf_mod2_ind_var_gamma1.strat, 2, mean), apply(gvf_mod2_ind_var_gamma2.strat, 2, mean), apply(gvf_mod2_ind_var_pois1.strat, 2, mean), apply(gvf_mod2_ind_var_pois2.strat, 2, mean),
                                           apply(gvf_mod2_ind_var_gamma1.tsc, 2, mean), apply(gvf_mod2_ind_var_gamma2.tsc, 2, mean), apply(gvf_mod2_ind_var_pois1.tsc, 2, mean), apply(gvf_mod2_ind_var_pois2.tsc, 2, mean) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )


df.mod2w_ind.var <- data.frame( gvf.pred = c( apply(gvf_mod2w_ind_var_gamma1.srs, 2, mean), apply(gvf_mod2w_ind_var_gamma2.srs, 2, mean), apply(gvf_mod2w_ind_var_pois1.srs, 2, mean), apply(gvf_mod2w_ind_var_pois2.srs, 2, mean),
                                            apply(gvf_mod2w_ind_var_gamma1.strat, 2, mean), apply(gvf_mod2w_ind_var_gamma2.strat, 2, mean), apply(gvf_mod2w_ind_var_pois1.strat, 2, mean), apply(gvf_mod2w_ind_var_pois2.strat, 2, mean),
                                            apply(gvf_mod2w_ind_var_gamma1.tsc, 2, mean), apply(gvf_mod2w_ind_var_gamma2.tsc, 2, mean), apply(gvf_mod2w_ind_var_pois1.tsc, 2, mean), apply(gvf_mod2w_ind_var_pois2.tsc, 2, mean) ),
                                variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                                design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

# GVFs mod3 version
df.mod3_all.var <- data.frame( gvf.pred = c( apply(gvf_mod3_all_var_gamma1.srs, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_gamma2.srs, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_pois1.srs, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_pois2.srs, 2, mean, na.rm = TRUE),
                                           apply(gvf_mod3_all_var_gamma1.strat, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_gamma2.strat, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_pois1.strat, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_pois2.strat, 2, mean, na.rm = TRUE),
                                           apply(gvf_mod3_all_var_gamma1.tsc, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_gamma2.tsc, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_pois1.tsc, 2, mean, na.rm = TRUE), apply(gvf_mod3_all_var_pois2.tsc, 2, mean, na.rm = TRUE) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod3w_all.var <- data.frame( gvf.pred = c( apply(gvf_mod3w_all_var_gamma1.srs, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_gamma2.srs, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_pois1.srs, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_pois2.srs, 2, mean, na.rm = TRUE),
                                            apply(gvf_mod3w_all_var_gamma1.strat, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_gamma2.strat, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_pois1.strat, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_pois2.strat, 2, mean, na.rm = TRUE),
                                            apply(gvf_mod3w_all_var_gamma1.tsc, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_gamma2.tsc, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_pois1.tsc, 2, mean, na.rm = TRUE), apply(gvf_mod3w_all_var_pois2.tsc, 2, mean, na.rm = TRUE) ),
                                variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                                design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod4_all.var <- data.frame( gvf.pred = c( apply(gvf_mod4_all_var_gamma1.srs, 2, mean), apply(gvf_mod4_all_var_gamma2.srs, 2, mean), apply(gvf_mod4_all_var_pois1.srs, 2, mean), apply(gvf_mod4_all_var_pois2.srs, 2, mean),
                                           apply(gvf_mod4_all_var_gamma1.strat, 2, mean), apply(gvf_mod4_all_var_gamma2.strat, 2, mean), apply(gvf_mod4_all_var_pois1.strat, 2, mean), apply(gvf_mod4_all_var_pois2.strat, 2, mean),
                                           apply(gvf_mod4_all_var_gamma1.tsc, 2, mean), apply(gvf_mod4_all_var_gamma2.tsc, 2, mean), apply(gvf_mod4_all_var_pois1.tsc, 2, mean), apply(gvf_mod4_all_var_pois2.tsc, 2, mean) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod4w_all.var <- data.frame( gvf.pred = c( apply(gvf_mod4w_all_var_gamma1.srs, 2, mean), apply(gvf_mod4w_all_var_gamma2.srs, 2, mean), apply(gvf_mod4w_all_var_pois1.srs, 2, mean), apply(gvf_mod4w_all_var_pois2.srs, 2, mean),
                                            apply(gvf_mod4w_all_var_gamma1.strat, 2, mean), apply(gvf_mod4w_all_var_gamma2.strat, 2, mean), apply(gvf_mod4w_all_var_pois1.strat, 2, mean), apply(gvf_mod4w_all_var_pois2.strat, 2, mean),
                                            apply(gvf_mod4w_all_var_gamma1.tsc, 2, mean), apply(gvf_mod4w_all_var_gamma2.tsc, 2, mean), apply(gvf_mod4w_all_var_pois1.tsc, 2, mean), apply(gvf_mod4w_all_var_pois2.tsc, 2, mean) ),
                                variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                                design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

df.mod4_ind.var <- data.frame( gvf.pred = c( apply(gvf_mod4_ind_var_gamma1.srs, 2, mean), apply(gvf_mod4_ind_var_gamma2.srs, 2, mean), apply(gvf_mod4_ind_var_pois1.srs, 2, mean), apply(gvf_mod4_ind_var_pois2.srs, 2, mean),
                                           apply(gvf_mod4_ind_var_gamma1.strat, 2, mean), apply(gvf_mod4_ind_var_gamma2.strat, 2, mean), apply(gvf_mod4_ind_var_pois1.strat, 2, mean), apply(gvf_mod4_ind_var_pois2.strat, 2, mean),
                                           apply(gvf_mod4_ind_var_gamma1.tsc, 2, mean), apply(gvf_mod4_ind_var_gamma2.tsc, 2, mean), apply(gvf_mod4_ind_var_pois1.tsc, 2, mean), apply(gvf_mod4_ind_var_pois2.tsc, 2, mean) ),
                               variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                               design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )


df.mod4w_ind.var <- data.frame( gvf.pred = c( apply(gvf_mod4w_ind_var_gamma1.srs, 2, mean), apply(gvf_mod4w_ind_var_gamma2.srs, 2, mean), apply(gvf_mod4w_ind_var_pois1.srs, 2, mean), apply(gvf_mod4w_ind_var_pois2.srs, 2, mean),
                                            apply(gvf_mod4w_ind_var_gamma1.strat, 2, mean), apply(gvf_mod4w_ind_var_gamma2.strat, 2, mean), apply(gvf_mod4w_ind_var_pois1.strat, 2, mean), apply(gvf_mod4w_ind_var_pois2.strat, 2, mean),
                                            apply(gvf_mod4w_ind_var_gamma1.tsc, 2, mean), apply(gvf_mod4w_ind_var_gamma2.tsc, 2, mean), apply(gvf_mod4w_ind_var_pois1.tsc, 2, mean), apply(gvf_mod4w_ind_var_pois2.tsc, 2, mean) ),
                                variables = rep( rep(c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2"), each = 50 ), times = 3 ),
                                design = rep( c("SRS", "StratRS", "Stratified TSC"), each = 4*50) )

##########################################################################
##########################################################################
df.mod1_all.var$weighted <- df.mod1_ind.var$weighted <- df.mod2_all.var$weighted <- df.mod2_ind.var$weighted <- df.mod3_all.var$weighted <- df.mod4_all.var$weighted <- df.mod4_ind.var$weighted <- FALSE
df.mod1w_all.var$weighted <- df.mod1w_ind.var$weighted <- df.mod2w_all.var$weighted <- df.mod2w_ind.var$weighted <- df.mod3w_all.var$weighted <- df.mod4w_all.var$weighted <- df.mod4w_ind.var$weighted <- TRUE

df.mod1_all.var$model <- df.mod1w_all.var$model <- df.mod1_ind.var$model <- df.mod1w_ind.var$model <- "log-log"
df.mod2_all.var$model <- df.mod2w_all.var$model <- df.mod2_ind.var$model <- df.mod2w_ind.var$model <- "relVar"
df.mod3_all.var$model <- df.mod3w_all.var$model <- "nonlinear"
df.mod4_all.var$model <- df.mod4w_all.var$model <- df.mod4_ind.var$model <- df.mod4w_ind.var$model <- "linear"

df.mod1_all.var$variable.specific.gvf <- df.mod2_all.var$variable.specific.gvf <- 
  df.mod3_all.var$variable.specific.gvf <- df.mod4_all.var$variable.specific.gvf <-
  df.mod1w_all.var$variable.specific.gvf <- df.mod2w_all.var$variable.specific.gvf <- 
  df.mod3w_all.var$variable.specific.gvf <- df.mod4w_all.var$variable.specific.gvf <- FALSE

df.mod1_ind.var$variable.specific.gvf <- df.mod2_ind.var$variable.specific.gvf <- 
 df.mod4_ind.var$variable.specific.gvf <-  df.mod1w_ind.var$variable.specific.gvf <- 
  df.mod2w_ind.var$variable.specific.gvf <- df.mod4w_ind.var$variable.specific.gvf <- TRUE


df.gvf.var <- rbind(df.mod1_all.var, df.mod1w_all.var, df.mod1_ind.var, df.mod1w_ind.var,
                    df.mod2_all.var, df.mod2w_all.var, df.mod2_ind.var, df.mod2w_ind.var,
                    df.mod3_all.var, df.mod3w_all.var, 
                    df.mod4_all.var, df.mod4w_all.var, df.mod4_ind.var, df.mod4w_ind.var )

df.mc.truevar <- aggregate( df.mc.var$mcvar, by = list( variables = df.mc.var$variables, design = df.mc.var$design), mean )

ind <- paste0(df.mc.truevar$design, df.mc.truevar$variables)
ind <- match( paste0(df.gvf.var$design, df.gvf.var$variables), ind )
df.gvf.var$mctrue <- df.mc.truevar$x[ind]
df.gvf.var$err <- df.gvf.var$gvf.pred - df.gvf.var$mctrue
df.gvf.var$rel.err <- df.gvf.var$err/df.gvf.var$mctrue 

# Summary Statistics Relative Error of All Models  
sp <- with( df.gvf.var, split( df.gvf.var, list(variable.specific.gvf, weighted, design, model)) )
out <- lapply(sp, function(x) tapply(x$rel.err, x$variables, summary))
lapply(out, function(x) lapply(x, round, digits = 3))

df.gvf.var.short <- df.gvf.var[df.gvf.var$model != "nonlinear" & df.gvf.var$variable.specific.gvf, ]
sp <- with( df.gvf.var.short, split( df.gvf.var.short, list(variable.specific.gvf, weighted, design, model)) )
out <- lapply(sp, function(x) tapply(x$rel.err^2, x$variables, summary))
lapply(out, function(x) lapply(x, round, digits = 3))

# Overall, the linear model is slightly worse
df.gvf.var.short <- df.gvf.var.short[df.gvf.var.short$model != "linear", ]

# Updating columns of df.direct.var
ind <- paste0(df.mc.truevar$design, df.mc.truevar$variables)
ind <- match( paste0(df.direct.var$design, df.direct.var$variables), ind )
df.direct.var$weighted <- FALSE
df.direct.var$model <- "direct"
df.direct.var$variable.specific.gvf <- TRUE
df.direct.var$mctrue <- df.mc.truevar$x[ind]
df.direct.var$err <- df.direct.var$directvar - df.direct.var$mctrue
df.direct.var$rel.err <- df.direct.var$err/df.direct.var$mctrue

# Updating data.frame for resampling estimators
ind <- paste0(df.mc.truevar$design, df.mc.truevar$variables)
ind <- match( paste0(df.rep.var$design, df.rep.var$variables), ind )
df.rep.var$weighted <- FALSE
df.rep.var$model <- "resampling"
df.rep.var$variable.specific.gvf <- TRUE
df.rep.var$mctrue <- df.mc.truevar$x[ind]
df.rep.var$err <- df.rep.var$repvar - df.rep.var$mctrue
df.rep.var$rel.err <- df.rep.var$err/df.rep.var$mctrue

colnames(df.rep.var)[1] <- colnames(df.direct.var)[1] <- colnames(df.gvf.var.short)[1] <- "est.var"
df.all.var <- rbind(df.direct.var, df.rep.var, df.gvf.var.short)

# Now, take a look on the R^2 etc.
df.gvf.r2 <- data.frame(r2 = c( mean(r2_mod1_all.srs, na.rm = TRUE), mean(r2_mod1_all.strat, na.rm = TRUE), mean(r2_mod1_all.tsc, na.rm = TRUE),
                                mean(r2_mod1w_all.srs, na.rm = TRUE), mean(r2_mod1w_all.strat, na.rm = TRUE), mean(r2_mod1w_all.tsc, na.rm = TRUE),
                                mean(r2_mod1_ind.srs, na.rm = TRUE), mean(r2_mod1_ind.strat, na.rm = TRUE), mean(r2_mod1_ind.tsc, na.rm = TRUE), 
                                mean(r2_mod1w_ind.srs, na.rm = TRUE), mean(r2_mod1w_ind.strat, na.rm = TRUE), mean(r2_mod1w_ind.tsc, na.rm = TRUE),
                                mean(r2_mod2_all.srs, na.rm = TRUE), mean(r2_mod2_all.strat, na.rm = TRUE), mean(r2_mod2_all.tsc, na.rm = TRUE),
                                mean(r2_mod2w_all.srs, na.rm = TRUE), mean(r2_mod2w_all.strat, na.rm = TRUE), mean(r2_mod2w_all.tsc, na.rm = TRUE),
                                mean(r2_mod2_ind.srs, na.rm = TRUE), mean(r2_mod2_ind.strat, na.rm = TRUE), mean(r2_mod2_ind.tsc, na.rm = TRUE), 
                                mean(r2_mod2w_ind.srs, na.rm = TRUE), mean(r2_mod2w_ind.strat, na.rm = TRUE), mean(r2_mod2w_ind.tsc, na.rm = TRUE),
                                mean(r2_mod4_all.srs, na.rm = TRUE), mean(r2_mod4_all.strat, na.rm = TRUE), mean(r2_mod4_all.tsc, na.rm = TRUE),
                                mean(r2_mod4w_all.srs, na.rm = TRUE), mean(r2_mod4w_all.strat, na.rm = TRUE), mean(r2_mod4w_all.tsc, na.rm = TRUE),
                                mean(r2_mod4_ind.srs, na.rm = TRUE), mean(r2_mod4_ind.strat, na.rm = TRUE), mean(r2_mod4_ind.tsc, na.rm = TRUE), 
                                mean(r2_mod4w_ind.srs, na.rm = TRUE), mean(r2_mod4w_ind.strat, na.rm = TRUE), mean(r2_mod4w_ind.tsc, na.rm = TRUE) )  )

df.hv <- unique(cbind( df.gvf.var$model, df.gvf.var$variable.specific.gvf, df.gvf.var$weighted, df.gvf.var$design) )
colnames(df.hv) <- c("model", "variable.specific.gvf", "weighted", "design")
df.gvf.r2 <- cbind(df.gvf.r2, df.hv[df.hv[,1] != "nonlinear",]) 

df.gvf.r2$gersh <- c( mean(gersh_mod1_all.srs, na.rm = TRUE), mean(gersh_mod1_all.strat, na.rm = TRUE), mean(gersh_mod1_all.tsc, na.rm = TRUE),
                         mean(gersh_mod1w_all.srs, na.rm = TRUE), mean(gersh_mod1w_all.strat, na.rm = TRUE), mean(gersh_mod1w_all.tsc, na.rm = TRUE),
                         mean(gersh_mod1_ind.srs, na.rm = TRUE), mean(gersh_mod1_ind.strat, na.rm = TRUE), mean(gersh_mod1_ind.tsc, na.rm = TRUE), 
                         mean(gersh_mod1w_ind.srs, na.rm = TRUE), mean(gersh_mod1w_ind.strat, na.rm = TRUE), mean(gersh_mod1w_ind.tsc, na.rm = TRUE),
                         mean(gersh_mod2_all.srs, na.rm = TRUE), mean(gersh_mod2_all.strat, na.rm = TRUE), mean(gersh_mod2_all.tsc, na.rm = TRUE),
                         mean(gersh_mod2w_all.srs, na.rm = TRUE), mean(gersh_mod2w_all.strat, na.rm = TRUE), mean(gersh_mod2w_all.tsc, na.rm = TRUE),
                         mean(gersh_mod2_ind.srs, na.rm = TRUE), mean(gersh_mod2_ind.strat, na.rm = TRUE), mean(gersh_mod2_ind.tsc, na.rm = TRUE), 
                         mean(gersh_mod2w_ind.srs, na.rm = TRUE), mean(gersh_mod2w_ind.strat, na.rm = TRUE), mean(gersh_mod2w_ind.tsc, na.rm = TRUE),
                         mean(gersh_mod4_all.srs, na.rm = TRUE), mean(gersh_mod4_all.strat, na.rm = TRUE), mean(gersh_mod4_all.tsc, na.rm = TRUE),
                         mean(gersh_mod4w_all.srs, na.rm = TRUE), mean(gersh_mod4w_all.strat, na.rm = TRUE), mean(gersh_mod4w_all.tsc, na.rm = TRUE),
                         mean(gersh_mod4_ind.srs, na.rm = TRUE), mean(gersh_mod4_ind.strat, na.rm = TRUE), mean(gersh_mod4_ind.tsc, na.rm = TRUE), 
                         mean(gersh_mod4w_ind.srs, na.rm = TRUE), mean(gersh_mod4w_ind.strat, na.rm = TRUE), mean(gersh_mod4w_ind.tsc, na.rm = TRUE) )

df.gvf.r2 <- rbind( df.gvf.r2, cbind(r2 = rep(NA, 6), df.hv[df.hv[,"model"] == "nonlinear",], 
                                     gersh = c(mean(gersh_mod3_all.srs), mean(gersh_mod3_all.strat), mean(gersh_mod3_all.tsc),
                                     mean(gersh_mod3w_all.srs), mean(gersh_mod3w_all.strat), mean(gersh_mod3w_all.tsc))))

hv <- with( df.gvf.var, aggregate( rel.err, list(model, variable.specific.gvf, weighted, design), function(x) mean(x^2), simplify = FALSE ) )
hv$Group.4 <- as.numeric(hv$Group.4)
ind <- match( apply( df.gvf.r2[,c("model", "variable.specific.gvf", "weighted", "design")], 1, paste, collapse = ""), 
              gsub(" ", "", apply( hv[,c("Group.1", "Group.2", "Group.3", "Group.4")], 1, paste, collapse = "") ) )
df.gvf.r2$rel.err <- unlist(hv$x)[ind]

df.gvf.r2$model2 <- with(df.gvf.r2, interaction( model, variable.specific.gvf ) )
df.gvf.r2$design2 <- with(df.gvf.r2, interaction( design, weighted ) )
df.gvf.r2$r2 <- as.numeric(df.gvf.r2$r2)
df.gvf.r2$gersh <- as.numeric(df.gvf.r2$gersh)

library(ggplot2)
distr_label = c("Y %~% Gamma(3,2)", "Y %~% Gamma(8,3)", "Y %~% plain(Pois)(6)", "Y %~% plain(Pois)(24)")
names(distr_label) <- c("Gamma - 1", "Gamma - 2", "Poisson - 1", "Poisson - 2")

ggplot(data = df.mc.var, aes(x = design, y = mcvar) ) + geom_boxplot( notch = TRUE ) +
  facet_grid( .~ variables, labeller = as_labeller(distr_label, label_parsed), scales = "free") +
  theme( axis.text.x = element_text(angle = 30), text = element_text(size = 15), legend.position="bottom") + 
  labs(y = "MC-Variance")

pdf("performance_direct_variance_estimator.pdf", width = 12)
ggplot(data = df.direct.var, aes(x = design, y = est.var) ) + geom_boxplot( notch = TRUE ) +
  facet_grid( .~ variables, labeller = as_labeller(distr_label, label_parsed), scales = "free") +
  labs(y = "HT Variance Estimate", x = "Design") + scale_x_discrete( labels = c("SRS", "Stratified \n TSC", "StratRS")) +
  geom_point(data = df.mc.truevar, aes(x = design, y = x, color = "black"), shape = 4, size = 3.5, show.legend = TRUE ) +
  theme(legend.title = element_blank(), text = element_text(size = 15), legend.position = "bottom" ) + 
  scale_color_manual(name = element_blank(), labels = "MC mean of HT", values = 1)
dev.off()

est.lab <- c("Direct", "GVF log-log \n Indicator + WOLS",  "GVF relVar \n Indicator + WOLS","Resampling")
names(est.lab) <- c("direct", "log-log", "relVar", "resampling")

est.lab2 <- c("Direct", "GVF log-log \n Indicator",  "GVF relVar \n Indicator", "Resampling", 
              "GVF log-log \n Indicator + WOLS",  "GVF relVar \n Indicator + WOLS")
names(est.lab2) <- c("direct.FALSE", "log-log.FALSE", "relVar.FALSE", "resampling.FALSE", "log-log.TRUE", "relVar.TRUE" )

pdf("performance_all_vars.pdf", width = 12)
ggplot( data = df.all.var, aes(x = variables, y = rel.err, fill = interaction(model, weighted, drop = TRUE)) ) +
  geom_boxplot( notch = TRUE ) +
  facet_wrap(.~ design,  scales = "free", shrink = TRUE ) + labs(y = "Relative Error", x = "Distribution of Y") +
  scale_x_discrete( labels = c(expression(Gamma(3,2)), expression(Gamma(8,3)), expression(plain(Pois)(6)), expression( plain(Pois)(24))) ) + 
  theme( text = element_text(size = 15), legend.position = "bottom") +
  scale_fill_discrete(name = "Estimator",  labels = est.lab2)
dev.off()

############ Plot Quality Measures 

pdf("quality_measures_r2.pdf", width = 12)
ggplot( data = df.gvf.r2[df.gvf.r2$model != "nonlinear",], aes(x = rel.err, y = r2 ) ) + 
  geom_point(stat = "identity", size = 3, position = position_jitter(), aes(shape = weighted, colour = model2)) + 
  xlim(c(0,0.4)) +
  facet_grid( .~ design, labeller = as_labeller(c("1" = "SRS", "2" = "Stratified TSC", "3" = "StratRS")) ) +
  scale_color_brewer(type = "qual", name = "Model", labels = c( "linear", "log-log", "relVar", "linear (indicators)",
                                                               "log-log (indicators)", "relVar (indicators)")) +
  scale_shape_discrete( name = "Estimation", labels = c("OLS", "weighted OLS") ) +
  xlab( "Avrg. squared relative error" ) + ylab(expression(R^2)) +
  theme( text = element_text(size = 15), legend.position = "bottom")
dev.off()

pdf("quality_measures_gersh.pdf", width = 12)
ggplot( data = df.gvf.r2[df.gvf.r2$model != "nonlinear",], aes(x = rel.err, y = gersh, colour = model2, shape = weighted ) ) + 
  facet_grid( .~ design,  labeller = as_labeller(c("1" = "SRS", "2" = "Stratified TSC", "3" = "StratRS")) ) +
  geom_point(stat = "identity", size = 3, alpha = 1, position = position_jitter()) + xlim(c(0,0.4)) + ylim(c(0,1)) +
  scale_color_brewer(type = "qual", name = "Model", labels = c( "linear", "log-log", "relVar", "linear (indicators)",
                                                                "log-log (indicators)", "relVar (indicators)")) +
  scale_shape_discrete( name = "Estimation", labels = c("OLS", "weighted OLS") ) +
  xlab( "Avrg. squared relative error" ) + ylab(expression(delta)) +
  geom_hline(yintercept = 0.95, color = "darkred") + 
  theme( text = element_text(size = 15), legend.position = "bottom")
dev.off()
mean(gersh_direct.srs)
mean(gersh_direct.strat)
mean(gersh_direct.tsc)
df.gvf.r2[df.gvf.r2$design == 1,]
df.gvf.r2[df.gvf.r2$design == 3,]
df.gvf.r2[df.gvf.r2$design == 2,]
df.gvf.r2[as.logical(df.gvf.r2$weighted) & as.logical(df.gvf.r2$variable.specific.gvf) & (df.gvf.r2$model %in% c("log-log", "relVar")),]
