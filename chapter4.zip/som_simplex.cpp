#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;
using namespace std;

#define ARMA_USE_LAPACK
#define ARMA_USE_BLAS

//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
vec bandwidth_calc( const sp_mat& neighbors ){
  uword nnodes = neighbors.n_cols;
  uword j;
  vec bandwidth(nnodes);
  mat neighbors2 = mat(neighbors);
  
  for( j = 0; j < nnodes; j++){
    uvec ind = find(neighbors2.col(j) == 1);
    bandwidth(j) = (ind.n_elem-1) * 0.5 + 0.5;
  }
  return(bandwidth);
}

// X is p x n and weights is p x nnodes, output is n x nnodes
//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
mat distance_fu(const mat& weights, const mat& X, const mat& varmat){
  
  uword n_obs = X.n_cols;
  uword n_nodes = weights.n_cols;
  uword p = X.n_rows;
  mat dist_w(n_obs, n_nodes);
  
  vec hv(p);
  vec wi(p);
  
  double dist;
  
  for(uword j = 0; j < n_nodes; j++){
    wi = weights.col(j);
    
    for(uword i = 0; i < n_obs; i++){
      hv = X.col(i);
      dist =  as_scalar(  (wi - hv).t() * varmat * (wi - hv) );
      dist_w(i,j) = dist;
    }
  }
  
  return(dist_w);
}

// distmat is n x nnodes
// Old armadillo version cannot handle this function:
//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
// uvec find_mindist( mat& distmat){
//   uvec ret = index_min(distmat,1);
//   return(ret);
// }
uvec find_mindist( mat& distmat){
  uword ind;
  uword n = distmat.n_rows; 
  uword i;
  uvec ret(n);
  double minval;
  for( i = 0; i < n; i++){
    minval = min(distmat.row(i));
    uvec indvec = find( distmat.row(i) == minval);
    ret(i) = indvec(0);
  }
  return(ret);
}

// simplex has dimension 3 x nnodes
//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
sp_umat simplex_neighbor( const umat& simplex, int nnodes ){
  
  uword nsimplex = simplex.n_cols;
  uword i, j;
  urowvec ind;
  sp_umat dist(nnodes, nnodes);
  
  if(nsimplex > 1){
    for(i = 0; i < nnodes; i++){
      ind = any(simplex == i, 0);
      uvec neighbours = unique( vectorise(simplex.cols(find(ind == 1))) );
      uvec values(nnodes, fill::zeros);
      values(neighbours).ones();
      dist.col(i) = values;
    }
  }else{
    dist(0,0) = 1; dist(0,1) = 1; dist(0,2) = 1;
    dist(1,0) = 1; dist(1,1) = 1; dist(1,2) = 1;
    dist(2,0) = 1; dist(2,1) = 1; dist(2,2) = 1;
  }
  return(dist);
}

// Calculate bar(u)
//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
mat local_means( const mat& weights, const sp_mat& neighbors){
  uword p = weights.n_rows;
  uword nnodes = weights.n_cols;
  mat localmean(p, nnodes, fill::zeros);
  vec denominator(nnodes, fill::zeros);
  
  for( uword i = 0; i < nnodes; i++){
    for( uword j = 0; j < nnodes; j++ ){
      if(i == j){
        localmean.col(i) += 0.5 * weights.col(j);
        denominator(i) += 0.5;
      }else if(neighbors(i,j) == 1){
        localmean.col(i) += 0.5 * weights.col(j);
        denominator(i) += 0.5;
      }
    }
  }
  for( uword i = 0; i < nnodes; i++){
    localmean.col(i) /= denominator(i);
  }
  
  return(localmean);
}

// Value to be compared for alternative matching rule
//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
mat accu_dist( const mat& distmat, const sp_mat& neighbors ){
  uword nnodes = distmat.n_cols;
  uword n = distmat.n_rows;
  mat accu_mat(n, nnodes);
  for(uword j = 0; j < n; j++){
    vec dist(nnodes);
    for(uword i = 0; i < nnodes; i++){
      vec neighbor = vec( neighbors.col(i) );
      neighbor *= 0.5;
      neighbor(i) = 0.5;
      dist(i) = accu( distmat.row(j).t() % neighbor );
    }
    accu_mat.row(j) = dist.t();
  }
  return(accu_mat);
}

// Calculate optimal p of alternative energy
//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
mat voronoi_prob( const mat& distmat, double temperature, const sp_mat& neighbors ){
  uword nnodes = distmat.n_cols;
  uword n = distmat.n_rows;
  mat probs(n, nnodes);
  
  if(temperature > 0){
    
    for(uword j = 0; j < n; j++){
      vec dist(nnodes);
      for(uword i = 0; i < nnodes; i++){
        vec neighbor = vec( neighbors.col(i) );
        neighbor *= 0.5;
        neighbor(i) = 0.5;
        dist(i) = exp( -accu( distmat.row(j).t() % neighbor )/temperature );
      }
      probs.row(j) = dist.t()/accu(dist);
    }
  }else if(temperature == 0){
    probs.zeros();
    for(uword j = 0; j < n; j++){
      vec dist(nnodes);
      uword min_index;
      double minval;
      for(uword i = 0; i < nnodes; i++){
        vec neighbor = vec( neighbors.col(i) );
        neighbor *= 0.5;
        neighbor(i) = 0.5;
        dist(i) = accu( distmat.row(j).t() % neighbor );
        if(minval > dist(i)){
          minval = dist(i);
          min_index = i;
        }
      }
      probs(j,min_index) = 1;
    }
  }
  
  return(probs);
}

// Train the modified mini-batch SOM
//[[Rcpp::depends("RcppArmadillo")]]
//[[Rcpp::export]]
mat training_som( const mat& X, mat weights, const sp_mat& neighbors, int B, mat& varmat, const vec& bandwidth, double temperature, double scaledet ){
  uword n = X.n_cols;
  uword p = X.n_rows;
  uword nnodes = weights.n_cols;
  uword i, j, iota;
  uvec ind(n);
  mat distmat(n,nnodes);
  mat meanvec(p, nnodes);
  
  mat weightmatrices(p,p);
  mat probs(n,nnodes);
  
  int b = 0;
  double denominator;
  vec numerator(X.n_rows);
  
  for( b = 0; b < B; b++){
    // Calculate P(Y in V_j)
    distmat = distance_fu( weights, X, varmat );
    probs = voronoi_prob( distmat, temperature, neighbors );

    // Update Weights
    for( iota = 0; iota < nnodes; iota++){
      numerator.zeros();
      denominator = 0.;
      for(j = 0; j < n; j++){
        for( i = 0; i < nnodes; i++){
          if(i == iota){
            numerator += 0.5 * probs(j,i) * X.col(j);
            denominator += probs(j,i) * 0.5;
          }else if(neighbors(iota,i) == 1){
            numerator += 0.5 * probs(j,i) * X.col(j);
            denominator += probs(j,i) * 0.5;
          } 
        }
      }
      weights.col(iota) = numerator/denominator;
    }
    
    // Update weight matrices
    distmat = distance_fu( weights, X, varmat ); 
    probs = voronoi_prob( distmat, temperature, neighbors );

    for( iota = 0; iota < nnodes; iota++){
      mat individ_mat(p,p, fill::zeros);
      for(j = 0; j < n; j++){
        for(i = 0; i < nnodes; i++){
          if(i == iota){
            numerator = (X.col(j) - weights.col(i));
            individ_mat += 0.5 * numerator * numerator.t();
          }else if(neighbors(iota,i) == 1){
            numerator = (X.col(j) - weights.col(i));
            individ_mat += 0.5 * numerator * numerator.t();
          }
          weightmatrices += individ_mat * probs(j,iota);
        }
        // }
      }
    }
    double detti = std::pow( det(weightmatrices)/ scaledet * nnodes, 1./p );
    weightmatrices /= detti;
    weightmatrices = symmatl(weightmatrices); // Had troubles with symmetry due to machine precision
    varmat = inv_sympd(weightmatrices);
  }
  
  return(weights);
}


