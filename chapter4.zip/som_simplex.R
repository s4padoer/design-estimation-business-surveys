require(Rcpp)
require(RcppArmadillo)
require(Matrix)

sourceCpp(file = "som_simplex.cpp")

gsom_simplex <- function(X, Niter, max_nodes = round(nrow(X)*0.5), weights = NULL, mini.batch = 25, temperature = 2, tol = 0.02, trace = TRUE){
  require(reldist)
  Ns <- nrow(X)
  max_nodes  <- min(max_nodes, Ns-1)
  if(!is.logical(mini.batch)){
    ns <- max( mini.batch, 4) 
  }else{
    ns <- max( c(4, 0.3*Ns) )
  }
  
  if(!is.null(weights)){
    require(sampling)
    ip <- inclusionprobabilities(weights, ns)
    csurvey <- TRUE
  }else{
    csurvey <- FALSE
  }
  # Initialize weights and graph
  if(!is.null(weights)){
    meanvec <- colSums(X * weights)/sum(weights)
    Xstd <- t(X)
    varmat <- ( Xstd %*% (weights * t(Xstd) ) )/sum(weights)
  }else{
    meanvec <- colMeans(X)
    Xstd <- t(X)
    varmat <- var(t(Xstd) )
  }
  p <- nrow(Xstd)
  
  varmatinv <- try( solve(varmat) )
  if(class(varmatinv) == "try-error") varmatinv <- diag(p)

  Xstd <- t(X)
  scaledet <- det(varmat)

  
  # Start with 2 simplices and 4 nodes
  simplices <- matrix(c(1:3, 1, 3, 4), ncol = 2)
  if(!is.null(weights)){
    node_weights <- apply(Xstd, 1, function(x) c(min(x), wtd.quantile( x, q = c(0.33, 0.67), weight = weights), max(x) ) )
  }else{
    node_weights <- apply(Xstd, 1, function(x) c(min(x), quantile( x, prob = c(0.33, 0.67)), max(x) ) )
  }
  # node_weights <- apply(Xstd, 1, function(x) wtd.quantile( x, q = c(0, 0.33, 0.67, 1), weight = weights) )
  node_weights <- t(node_weights)
  n_nodes <- 4
  neighbours <- simplex_neighbor(simplices-1, 4)
  listmat <- varmatinv/(scaledet^(1/p))
  
  samp <- 1:Ns
  
  bandwidth <- bandwidth_calc(neighbours)
  is_growing <- TRUE
  lambda <- max( c(round(50/ns), 1) )
  
  kriterium <- FALSE
  
  for(b in 1:Niter){
    # (weighted) mini-batch sampling
    if(mini.batch){
      if(csurvey){
        ip <- inclusionprobabilities(weights, ns)
        samp <- UPmidzuno(ip)
        samp <- which(samp == 1)
      }else{
        samp <- sample(Ns, size = ns, replace = FALSE)
      }
    }
    
    # training
    node_weights_new <- training_som( matrix(Xstd[,samp], nrow = p), node_weights, neighbours, n_nodes * lambda, listmat, bandwidth, temperature, scaledet)
    eps <- sqrt( max( colSums((node_weights_new - node_weights)^2)/colSums(node_weights^2) ) )
    
    ### Component for node deletion: Still needs some fine-tuning ###
    
    # if( !identical( t(node_weights), unique(t(node_weights)) ) ){
    #   # if(ncol(simplices) > 1){
    #   find_duplicate <- sapply(1:n_nodes, function(i) { any( which( colSums( abs(node_weights - node_weights[,i]) ) < .Machine$double.eps) < i) } ) 
    #   node_ids <- which(find_duplicate)
    #   node_weights[,node_ids] <- node_weights[,node_ids] + matrix( rnorm(length(node_ids)*p, sd = 0.1), nrow = p )
    #   #   loose_neighbours <- which( (colSums(neighbours) - neighbours[,node_ids]) <= 1 )
    #   #   removes <- c(node_ids, loose_neighbours)
    #   #   ind <- apply( simplices, 2, function(x) any(x %in% removes ) )
    #   #   if(sum(ind) == ncol(simplices)){
    #   #     simplices <- matrix(1:3, ncol = 1)
    #   #     node_weights <- node_weights[,-removes]
    #   #     n_nodes <- ncol(node_weights)
    #   #     neighbours <- simplex_neighbor(simplices, 3)
    #   #     bandwidth <- bandwidth_calc(neighbours)
    #   #   }else{
    #   #     simplices <- simplices[,!ind]
    #   #     node_weights <- node_weights[,-removes]
    #   #     n_nodes <- ncol(node_weights)
    #   #     neighbours <- simplex_neighbor(simplices, n_nodes)
    #   #     bandwidth <- bandwidth_calc(neighbours)
    #   #   }
    #   # }
    # }
    dist_localmeans <- distance_fu( node_weights, Xstd[,samp], listmat)
    tab <- colMeans( voronoi_prob(dist_localmeans, temperature, neighbours) )
    
    # Growth criterion
    kriterium <- max(abs(tab - 1/n_nodes), na.rm = TRUE)/(1 + 1/n_nodes)  < tol

    if( n_nodes > max_nodes){
      is_growing <- FALSE
    }else{
      is_growing <- !kriterium
    }
    
    if( is_growing ){
      out <- growsimplex(which.max(tab), node_weights, neighbours, simplices, Xstd, listmat)
      n_nodes <- out$n_nodes
      node_weights <- out$node_weights
      simplices <- out$simplices
      neighbours <- out$neighbours
      bandwidth <- out$bandwidth
      rm(out)
      
      if(n_nodes >= max_nodes){
        is_growing <- FALSE
      }
    }
    if(trace){
      print(b)
    }
    if(eps < 1e-6) break;
  }
  
  dist_localmeans <- distance_fu( node_weights, Xstd[,samp], listmat)
  tab <- colMeans( voronoi_prob(dist_localmeans, temperature, neighbours) )
  
  ret <- list()
  ret$node_weights <- t( node_weights )
  ret$node_metric <- listmat
  ret$densities    <- tab
  ret$simplices <- t( simplices )
  ret$neighbours <- neighbours
  ret$input <- X
  ret$varmat <- varmat
  ret$bandwidth <- bandwidth
  ret$temperature <- temperature
  ret$convergence <- eps < 1e-6
  
  return(ret)
}

# Grow graph
growsimplex <- function(most_winner, node_weights, neighbours, simplices, Xstd, listmat){
  n_nodes <- ncol(node_weights)
  p <- nrow(node_weights)
  winner_weights <- node_weights[,most_winner]
  
  # Finding Neighbours of bmu
  neighbours_ind <- which( neighbours[,most_winner] == 1 )
  neighbours_ind <- neighbours_ind[neighbours_ind != most_winner]
  
  if(length(neighbours_ind) > 1){
    neighbours_dist <- matrix(node_weights[,neighbours_ind], nrow = p) - winner_weights
    neighbours_dist <- apply(neighbours_dist, 2, function(x) crossprod(x, crossprod(listmat,x)) )
    neighbours_ind <- neighbours_ind[which.max(neighbours_dist)]
  }
  # Random convex combination of feature vectors for new node
  alpha <- runif(1)
  new_weight <- alpha * node_weights[,most_winner] + (1-alpha) * node_weights[,neighbours_ind]
  ind <- which( colSums( (simplices == most_winner) + (simplices == neighbours_ind) ) == 2 )
  ind_vert <- unique(c(simplices[,ind]))
  ind_vert <- ind_vert[!(ind_vert %in% c(most_winner, neighbours_ind) )]
  new_simplex <- sapply( ind_vert, function(x) return( c(x, most_winner, n_nodes+1, x, neighbours_ind, n_nodes +1) ) )
  new_simplex <- matrix(new_simplex, nrow = 3)
  
  simplices <- simplices[,-ind]
  simplices <- cbind(simplices, new_simplex)
  node_weights <- cbind(node_weights, new_weight)
  
  n_nodes <- n_nodes + 1
  
  neighbours <- simplex_neighbor(simplices-1, n_nodes)
  bandwidth <- bandwidth_calc(neighbours)
  
  return( list(simplices = simplices, bandwidth = bandwidth, node_weights = node_weights, n_nodes = n_nodes, neighbours = neighbours) )
}
