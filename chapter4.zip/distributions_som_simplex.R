# Build density estimator
distribution_som <- function(som ){
  require(MASS)
  require(Matrix)
  require(mvtnorm)
  features <- som$node_weights
  nnodes <- nrow(features)
  p <- ncol(features)
  varsinv <- som$node_metric
  bw <- som$bandwidth
  T <- som$temperature
  vars <- solve(varsinv)*T*0.5 # Derived covariance matrix from algorithm
  vars[upper.tri(vars)] <- vars[lower.tri(vars)] # Had problems with symmetry due to machine precision
  
  neighbours <- som$neighbours
  localvec <- local_means(t(features), som$neighbours)
  w <- som$neighbours * 0.5
  diag(w) <- 0.5
  if(T > 0){
    dens       <- exp(-rowSums( distance_fu(localvec, t(features), varsinv) * w)/T)
    dens      <- dens/sum(dens)
    scale_param <- as.numeric( 0.5 * T / bw)
  }else{
    dens <- rep(1/nnodes, nnodes)
    T <- 2
    scale_param <- rep(1.0, length(bw))
  }
  
  # Marginal distributions
  marginals <- lapply(1:p, function(pp){
    fu <- function(y){
      ret <- sapply(1:nnodes, function(i) dnorm(y, mean = localvec[pp,i], sd = sqrt(vars[pp,pp]/bw[i]) ) )
      ret <- colSums( t(ret) * dens )
      return(ret)
    }
    return(fu)
  })
  
  # Joint distribution
  joint <- function(x){
    ret <- colSums( t( sapply( 1:nnodes, function(i) dmvnorm(x, mean = localvec[,i], sigma = vars/bw[i] ) ) ) * dens )
    return(ret)
  }
  
  # univariate conditional density (given p-1 other variables)
  if( p > 1){
    conditionals <- list()
    
    for( i in 1:p){
      fu <- function(x, given){
        out <- sapply(1:nnodes, function(j){
          condvar <- vars[i,i] + sum( vars[i,-i] * ( varsinv[-i,-i] %*% vars[-i,i]))
          condexp <- localvec[i,j] + sum( vars[i,-i] * varsinv[-i,-i] %*% (given - localvec[-i,j]) )
          ret <- dnorm(x, mean = condexp, sd = sqrt( condvar/bw[j] ) )
          return(ret) } )
        return( colSums( t(out) * dens ) )
      }
      conditionals[[i]] <- fu
    }
  }else{
    conditionals <- NULL
  }
  return(list(marginaldens = marginals, conditionaldens = conditionals, jointdens = joint))
}

