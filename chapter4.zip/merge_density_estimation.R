#################################
# Merge results from simulation #
#################################
# Load estimates
library(abind)
lf <- list.files( path = "results")

load( paste0("results/", lf[1]) )
vars <- ls()[grepl("dist", ls())]

sim  <- gsub(".RData", "", lf[1] )
vars <- gsub(paste0("_", sim), "", vars)

for(x in vars){
  if(!grepl("dens", x) ) assign( x, t(get(paste0(x, "_", sim))) ) else assign( x, get(paste0(x, "_", sim)) )
}

rm( list = paste0(vars, "_", sim) )

for(s in lf[-1]){

  load( paste0("results/", s) )  
  sim <- gsub(".RData", "", s)
  
  for(x in vars){
    if( !grepl("dens", x) ){
      assign( x, rbind(get(x), t(get(paste0(x, "_", sim))) ) ) 
      }else{
      hv <- get(paste0(x, "_", sim) )
      if(any(hv == 0)) hv[hv == 0] <- NA
      assign(x, abind(get(x), hv, along = 2))
    }
  }
  rm( list = paste0(vars, "_", sim) )
  print(s)
}

dens_dist1_grid_gmm <- t( apply(dens_dist1_grid_gmm, 1, colMeans, na.rm = TRUE) )
dens_dist1_grid_kde <- t( apply(dens_dist1_grid_kde, 1, colMeans, na.rm = TRUE) )
dens_dist1_grid_som <- t( apply(dens_dist1_grid_som, 1, colMeans, na.rm = TRUE) )

dens_dist2_grid_gmm <- t( apply(dens_dist2_grid_gmm, 1, colMeans, na.rm = TRUE) )
dens_dist2_grid_kde <- t( apply(dens_dist2_grid_kde, 1, colMeans, na.rm = TRUE) )
dens_dist2_grid_som <- t( apply(dens_dist2_grid_som, 1, colMeans, na.rm = TRUE) )

dens_dist3_grid_gmm <- t( apply(dens_dist3_grid_gmm, 1, colMeans, na.rm = TRUE) )
dens_dist3_grid_kde <- t( apply(dens_dist3_grid_kde, 1, colMeans, na.rm = TRUE) )
dens_dist3_grid_som <- t( apply(dens_dist3_grid_som, 1, colMeans, na.rm = TRUE) )

gc()

# For evaluation with true densities: MC integration for true densities (take the points generated earlier)
library(evd)
library(mvtnorm)
set.seed(1)
N <- 1e4
intervals <- c(1/6, 3/6, 1)
mus <- matrix(c(0,0,
                1,1,
                7,7), ncol = 3)

covmats <- list( matrix( c(1,0,0,1), ncol = 2), matrix( c(3, 1, 1, 2), ncol = 2), matrix( c(9, 4, 4, 4), ncol = 2) )
chols   <- lapply(covmats, function(m) t(chol(m)) )
indicator <- runif(N, min = 0, max = 1)
indicator <- findInterval(indicator, intervals) + 1
grid_dat_dist1  <- rmvnorm(N, mean = c(0,0), diag(2))
grid_dat_dist1  <- sapply(1:N, function(i) as.numeric( chols[[indicator[i]]] %*% grid_dat_dist1[i,] + mus[,indicator[i]] ) )
grid_dat_dist1  <- t(grid_dat_dist1)

grid_dat_dist2 <- rexp(1e4, rate = 3)
grid_dat_dist2 <- cbind(grid_dat_dist2, rlnorm(1e4, meanlog = grid_dat_dist2))

grid_dat_dist3 <- rbvevd(1e4, dep = 0.3)

dens_dist1 <- function( mat ){
  out <- dmvnorm(mat, mean = mus[,1], sigma = covmats[[1]])/6 + dmvnorm(mat, mean = mus[,2], sigma = covmats[[2]])/3 + dmvnorm(mat, mean = mus[,3], sigma = covmats[[3]])/2
  return(out)
}
dens_dist2 <- function( mat ){
  out <- apply(mat, 1, function(x) dexp(x[1], rate = 3) * dlnorm(x[2], meanlog = x[1]) )
  return(out)
}
true_dens1 <- dens_dist1( grid_dat_dist1 )  
true_dens2 <- dens_dist2( grid_dat_dist2 )
true_dens3 <- dbvevd( grid_dat_dist3, dep = 0.3)

# Calculate MC KL-Divergence and MISE
kl_som_dist1_avrg <- colMeans( log(true_dens1) - log( dens_dist1_grid_som ) )
kl_som_dist2_avrg <- colMeans( log(true_dens2) - log( dens_dist2_grid_som ) )
kl_som_dist3_avrg <- colMeans( log(true_dens3) - log( dens_dist3_grid_som ) )

mise_som_dist1_avrg <- colMeans( (true_dens1 - dens_dist1_grid_som )^2 )
mise_som_dist2_avrg <- colMeans( (true_dens2 - dens_dist2_grid_som )^2 )
mise_som_dist3_avrg <- colMeans( (true_dens3 - dens_dist3_grid_som )^2 )

kl_gmm_dist1_avrg <- colMeans( log(true_dens1) - log( dens_dist1_grid_gmm ) )
kl_gmm_dist2_avrg <- colMeans( log(true_dens2) - log( dens_dist2_grid_gmm ) )
kl_gmm_dist3_avrg <- colMeans( log(true_dens3) - log( dens_dist3_grid_gmm ) )

mise_gmm_dist1_avrg <- colMeans( (true_dens1 - dens_dist1_grid_gmm )^2 )
mise_gmm_dist2_avrg <- colMeans( (true_dens2 - dens_dist2_grid_gmm )^2 )
mise_gmm_dist3_avrg <- colMeans( (true_dens3 - dens_dist3_grid_gmm )^2 )

kl_kde_dist1_avrg <- colMeans( log(true_dens1) - log( dens_dist1_grid_kde ) )
kl_kde_dist2_avrg <- colMeans( log(true_dens2) - log( dens_dist2_grid_kde ) )
kl_kde_dist3_avrg <- colMeans( log(true_dens3) - log( dens_dist3_grid_kde ) )

mise_kde_dist1_avrg <- colMeans( (true_dens1 - dens_dist1_grid_kde )^2 )
mise_kde_dist2_avrg <- colMeans( (true_dens2 - dens_dist2_grid_kde )^2 )
mise_kde_dist3_avrg <- colMeans( (true_dens3 - dens_dist3_grid_kde )^2 )
####################################################

# save.image(file = "merged_density_estimation.RData")

# Generate plots
library(ggplot2)
library(gridExtra)

load("merged_density_estimation.RData")

df_dist1 <- data.frame( estimator = rep( c("SOM", "KDE", "GMM"), each =  nrow(mise_som_dist1)*3),
                        n         = rep( rep( as.factor(c(50, 100, 200)), each =  nrow(mise_som_dist1) ), times = 3 ),
                        mise      = c(mise_som_dist1, mise_kde_dist1, mise_gmm_dist1),
                        kl        = c(kl_som_dist1, kl_kde_dist1, kl_gmm_dist1) )

df_dist2 <- data.frame( estimator = rep( c("SOM", "KDE", "GMM"), each =  nrow(mise_som_dist2)*3),
                        n         = rep( rep( as.factor(c(50, 100, 200)), each =  nrow(mise_som_dist2) ), times = 3),
                        mise      = c(mise_som_dist2, mise_kde_dist2, mise_gmm_dist2),
                        kl        = c(kl_som_dist2, kl_kde_dist2, kl_gmm_dist2) )

df_dist3 <- data.frame( estimator = rep( c("SOM", "KDE", "GMM"), each =  nrow(mise_som_dist3)*3),
                        n         = rep(rep( as.factor(c(50, 100, 200)), each =  nrow(mise_som_dist3) ), times = 3),
                        mise      = c(mise_som_dist3, mise_kde_dist3, mise_gmm_dist3),
                        kl        = c(kl_som_dist3, kl_kde_dist3, kl_gmm_dist3) )

plot1 <- ggplot(data = df_dist1, aes(x = n, y = mise, fill = estimator)) + geom_boxplot( notch = TRUE) + 
  labs( x = "Sample size", y = "MISE", fill = "Estimator") + ylim(c(0,0.0005)) +
  theme(text = element_text(size = 15), legend.position = "bottom") +
  stat_summary(fun.y=mean, geom="point", aes(group = estimator), position=position_dodge(0.75), 
               size=2, color="darkred", fill="darkred")

plot2 <- ggplot(data = df_dist1, aes(x = n, y = kl, fill = estimator)) + geom_boxplot( notch = TRUE) + 
  labs( x = "Sample size", y = "Kullback-Leibler", fill = "Estimator") + ylim(c(0,2.5)) + 
  theme(text = element_text(size=15), legend.position = "bottom") +
  stat_summary(fun.y=mean, geom="point", aes(group = estimator), position=position_dodge(0.75), 
               size=2, color="darkred", fill="darkred")

ylim <- boxplot(df_dist2$mise, plot = FALSE)$stats[c(1,5)]
plot3 <- ggplot(data = df_dist2, aes(x = n, y = mise, fill = estimator)) + geom_boxplot( notch = TRUE) + 
  labs( x = "Sample size", y = "MISE", fill = "Estimator") + 
  theme(text = element_text(size=15), legend.position = "bottom") +
  stat_summary(fun.y=mean, geom="point", aes(group = estimator), position=position_dodge(0.75), 
               size=2, color="darkred", fill="darkred") + ylim( ylim * c(0.85, 1.15) )

ylim <- boxplot(df_dist2$kl, plot = FALSE)$stats[c(1,5)]
plot4 <- ggplot(data = df_dist2, aes(x = n, y = kl, fill = estimator)) + geom_boxplot( notch = TRUE) + 
  labs( x = "Sample size", y = "Kullback-Leibler", fill = "Estimator") + 
  theme(text = element_text(size=15), legend.position = "bottom") +
  stat_summary(fun.y=mean, geom="point", aes(group = estimator), position=position_dodge(0.75), 
               size=2, color="darkred", fill="darkred") + ylim( ylim * c(0.85, 1.15) )

ylim <- boxplot(df_dist3$mise, plot = FALSE)$stats[c(1,5)]
plot5 <- ggplot(data = df_dist3, aes(x = n, y = mise, fill = estimator)) + geom_boxplot( notch = TRUE) + 
  labs( x = "Sample size", y = "MISE", fill = "Estimator") + 
  theme(text = element_text(size=15), legend.position = "bottom") +
  stat_summary(fun.y=mean, geom="point", aes(group = estimator), position=position_dodge(0.75), 
               size=2, color="darkred", fill="darkred") + ylim( ylim * c(0.8, 1.3) )

ylim = boxplot.stats(df_dist3$kl)$stats[c(1, 5)]
plot6 <- ggplot(data = df_dist3, aes(x = n, y = kl, fill = estimator)) + geom_boxplot( notch = TRUE) + 
  labs( x = "Sample size", y = "Kullback-Leibler", fill = "Estimator") + 
  theme(text = element_text(size=15), legend.position = "bottom") +
  stat_summary(fun.y=mean, geom="point", aes(group = estimator), position=position_dodge(0.75), 
               size=2, color="darkred", fill="darkred") + coord_cartesian(ylim = ylim*c(0.95, 1.5) )


pdf("dist1.pdf", width = 12)
grid.arrange(plot1, plot2)
dev.off()

pdf("dist2.pdf", width = 12)
grid.arrange(plot3, plot4)
dev.off()

pdf("dist3.pdf", width = 12)
grid.arrange(plot5, plot6)
dev.off()

