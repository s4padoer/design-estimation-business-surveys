####################################################################################
# Testing the developed extended SOM-Algorithm for multivariate density estimation #
####################################################################################
var <- as.integer( Sys.getenv("var") )

require(Rcpp)
require(RcppArmadillo)
require(mclust) # Gaussian Mixtures
require(ks) # Multivariate Kernel Density
require(evd) # Extreme Values
require(mvtnorm)

source("som_simplex.R")
source("distributions_som_simplex.R")

# sample sizes
ns <- c(50, 100, 150)
# Monte Carlo Replications
B  <- 10

# Initialize storage
# mise
mise_som_dist1 <- matrix(NA, ncol = B, nrow = length(ns))
mise_som_dist2 <- matrix(NA, ncol = B, nrow = length(ns))
mise_som_dist3 <- matrix(NA, ncol = B, nrow = length(ns))

mise_kde_dist1 <- matrix(NA, ncol = B, nrow = length(ns))
mise_kde_dist2 <- matrix(NA, ncol = B, nrow = length(ns))
mise_kde_dist3 <- matrix(NA, ncol = B, nrow = length(ns))

mise_gmm_dist1 <- matrix(NA, ncol = B, nrow = length(ns))
mise_gmm_dist2 <- matrix(NA, ncol = B, nrow = length(ns))
mise_gmm_dist3 <- matrix(NA, ncol = B, nrow = length(ns))

# kullback-leibler divergence
kl_som_dist1 <- matrix(NA, ncol = B, nrow = length(ns))
kl_som_dist2 <- matrix(NA, ncol = B, nrow = length(ns))
kl_som_dist3 <- matrix(NA, ncol = B, nrow = length(ns))

kl_kde_dist1 <- matrix(NA, ncol = B, nrow = length(ns))
kl_kde_dist2 <- matrix(NA, ncol = B, nrow = length(ns))
kl_kde_dist3 <- matrix(NA, ncol = B, nrow = length(ns))

kl_gmm_dist1 <- matrix(NA, ncol = B, nrow = length(ns))
kl_gmm_dist2 <- matrix(NA, ncol = B, nrow = length(ns))
kl_gmm_dist3 <- matrix(NA, ncol = B, nrow = length(ns))

count_fail_dist1 <- matrix(0, ncol = B, nrow = length(ns))
count_fail_dist2 <- matrix(0, ncol = B, nrow = length(ns))
count_fail_dist3 <- matrix(0, ncol = B, nrow = length(ns))

N <- 1e4
dens_dist1 <- array(data = 0, dim = c(N, B, length(ns)), dimnames = c("N", "B", "n"))
dens_dist2 <- array(data = 0, dim = c(N, B, length(ns)), dimnames = c("N", "B", "n"))
dens_dist3 <- array(data = 0, dim = c(N, B, length(ns)), dimnames = c("N", "B", "n"))

# Parameters for the test densities
intervals <- c(1/6, 3/6, 1)
mus <- matrix(c(0,0,
                1,1,
                7,7), ncol = 3)

covmats <- list( matrix( c(1,0,0,1), ncol = 2), matrix( c(3, 1, 1, 2), ncol = 2), matrix( c(9, 4, 4, 4), ncol = 2) )
chols   <- lapply(covmats, function(m) t(chol(m)) )

set.seed(var)

for(k in 1:length(ns)){
  n <- ns[k]
  for(b in 1:B){
    # Distribution 1: Multivariate Gaussian Mixture (three components)
    if(!exists("dens_dist1")){
      dens_dist1 <- function( mat ){
        out <- dmvnorm(mat, mean = mus[,1], sigma = covmats[[1]])/6 + dmvnorm(mat, mean = mus[,2], sigma = covmats[[2]])/3 + dmvnorm(mat, mean = mus[,3], sigma = covmats[[3]])/2
        return(out)
      }
    }
    indicator <- runif(n, min = 0, max = 1)
    indicator <- findInterval(indicator, intervals) + 1
    sim_data  <- rmvnorm(n, mean = c(0,0), diag(2))
    sim_data  <- sapply(1:n, function(i) as.numeric( chols[[indicator[i]]] %*% sim_data[i,] + mus[,indicator[i]] ) )
    sim_data  <- t(sim_data)
    
    kernel_est <- kde(sim_data, gridsize = n)
    som_dist   <- try( gsom_simplex(sim_data, Niter = 250, max_nodes = round( sqrt(n) ) * 6, temperature = 12, mini.batch = 10 ) )
    while(class(som_dist) == "try-error"){
      som_dist  <- try( gsom_simplex(sim_data, Niter = 250, max_nodes = round( sqrt(n) ) * 6, temperature = 12, mini.batch = 10 ) )
      count_fail_dist1[k,b] <- count_fail_dist1[k,b] + 1
      if(count_fail_dist1[k,b] > 9){
        break;
      }
    }
    
    gmm      <- densityMclust(sim_data)
    
    # Estimating MISE (MC)
    indicator <- runif(5000, min = 0, max = 1)
    indicator <- findInterval(indicator, intervals) + 1
    mise_dat  <- rmvnorm(5000, mean = c(0,0), diag(2))
    mise_dat  <- sapply(1:5000, function(i) as.numeric( chols[[indicator[i]]] %*% mise_dat[i,] + mus[,indicator[i]] ) )
    mise_dat  <- t(mise_dat)
    bench     <- dens_dist1(mise_dat)
    preds_kde <- predict(kernel_est, x = mise_dat)
    preds_gmm <- predict(gmm, newdata = mise_dat)
    mise_kde_dist1[k,b] <- mean( ( preds_kde - bench )^2 ) 
    mise_gmm_dist1[k,b] <- mean( ( preds_gmm - bench )^2 )
    
    vec <-  log(bench) - log(preds_kde)
    kl_kde_dist1[k,b]   <- mean( vec[is.finite(vec)] )
    vec <- log(bench) - log(preds_gmm)
    kl_gmm_dist1[k,b]   <- mean( vec[is.finite(vec)] )
    
    if(class(som_dist) != "try-error"){
      est_dist <- distribution_som(som_dist)
      preds_som <- est_dist$jointdens(mise_dat)
      mise_som_dist1[k,b] <- mean( ( preds_som - bench )^2 )
      vec <- log(bench) - log(preds_som)
      kl_som_dist1[k,b]   <- mean( vec[is.finite(vec)] )
    }
    # Distribution 2: Conditional Lognormal (conditioned on exponential distribution -- very skew)
    if(!exists("dens_dist2")){
      dens_dist2 <- function( mat ){
        out <- apply(mat, 1, function(x) dexp(x[1], rate = 3) * dlnorm(x[2], meanlog = x[1]) )
        return(out)
      }
    }
    sim_data  <- rexp(n, rate = 3)
    sim_data  <- cbind(sim_data, rlnorm(n, meanlog = sim_data))
    
    kernel_est <- kde(sim_data, gridsize = n)
    som_dist <- try( gsom_simplex(sim_data, Niter = 250, max_nodes = round( sqrt(n) ) * 6, temperature = 6, mini.batch = 10 ) )
    while(class(som_dist) == "try-error"){
      som_dist  <- try( gsom_simplex(sim_data, Niter = 250, max_nodes = round( sqrt(n) ) * 6, temperature = 6, mini.batch = 10 ) )
      count_fail_dist2[k,b] <- count_fail_dist2[k,b] + 1
      if(count_fail_dist2[k,b] > 9){
        break;
      }
    }
    
    gmm      <- densityMclust(sim_data)

    mise_dat <- rexp(5000, rate = 3)
    mise_dat <- cbind(mise_dat, rlnorm(5000, meanlog = mise_dat))
    bench    <- dens_dist2(mise_dat)
    preds_kde <- predict(kernel_est, x = mise_dat)
    preds_gmm <- predict(gmm, newdata = mise_dat)
    
    mise_kde_dist2[k,b] <- mean( ( preds_kde - bench )^2 ) 
    mise_gmm_dist2[k,b] <- mean( ( preds_gmm - bench )^2 )
    
    vec <- log(bench) - log(preds_kde)
    kl_kde_dist2[k,b] <- mean( vec[is.finite(vec)] )
    vec <- log(bench) - log(preds_gmm)
    kl_gmm_dist2[k,b] <- mean( vec[is.finite(vec)] )
    
    if(class(som_dist) != "try-error"){
      est_dist <- distribution_som(som_dist)
      preds_som <- est_dist$jointdens(mise_dat)
      mise_som_dist2[k,b] <- mean( ( preds_som - bench )^2 )
      vec <- log(bench) - log(preds_som)
      kl_som_dist2[k,b]   <- mean( vec[is.finite(vec)] )
    }
    # Distribution 3: bivariate logistic distribution
    sim_data <- rbvevd(n, dep = 0.3)
    kernel_est <- kde(sim_data, gridsize = n)
    som_dist <- try( gsom_simplex(sim_data, Niter = 250, max_nodes = round( sqrt(n) ) * 6, temperature = 26 ) )
    while(class(som_dist) == "try-error"){
      som_dist <- try( gsom_simplex(sim_data, Niter = 250, max_nodes = round( sqrt(n) ) * 6, temperature = 26 ) )
      count_fail_dist3[k,b] <- count_fail_dist3[k,b] + 1
      if(count_fail_dist3[k,b] > 9){
        break;
      }
    }
    gmm <- densityMclust(sim_data)
    # MISE Estimation: Simulate even more data from the distributions and evaluate the densities:
    mise_dat <- rbvevd(5000, dep = 0.3)
    bench    <- dbvevd(mise_dat, dep = 0.3)
    preds_kde <- predict(kernel_est, x = mise_dat)
    preds_gmm <- predict(gmm, newdata = mise_dat)
    
    mise_kde_dist3[k,b] <- mean( ( preds_kde - bench )^2 ) 
    mise_gmm_dist3[k,b] <- mean( ( preds_gmm - bench )^2 )
    
    vec <-  log(bench) - log(preds_kde)
    kl_kde_dist3[k,b]   <- mean( vec[is.finite(vec)] )
    vec <- log(bench) - log(preds_gmm)
    kl_gmm_dist3[k,b] <- mean( vec[is.finite(vec)] )
    
    if(class(som_dist) != "try-error"){
      est_dist <- distribution_som(som_dist)
      preds_som <- est_dist$jointdens(mise_dat)
      mise_som_dist3[k,b] <- mean( ( preds_som - bench )^2 )
      vec <- log(bench) - log(preds_som)
      kl_som_dist3[k,b]   <- mean( vec[is.finite(vec)] )
    }
    
    gc() 
  }
}

safe <- c("mise_kde_dist1", "mise_kde_dist2", "mise_kde_dist3",
          "mise_som_dist1", "mise_som_dist2", "mise_som_dist3",
          "mise_gmm_dist1", "mise_gmm_dist2", "mise_gmm_dist3",
          "kl_kde_dist1", "kl_kde_dist2", "kl_kde_dist3", 
          "kl_som_dist1", "kl_som_dist2", "kl_som_dist3",
          "kl_gmm_dist1", "kl_gmm_dist2", "kl_gmm_dist3",
          "count_fail_dist1", "count_fail_dist2", "count_fail_dist3")

for(x in safe){
  assign( paste0(x, "_sim", var), get(x) )
}
save( list = paste0(safe, "_sim", var), file = paste0("results/sim", var, ".RData") )
