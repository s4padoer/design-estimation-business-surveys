# Merge the simulation runs for survey-weighted mixed models

# True parameters
beta      <- c(7, -1, 1) # Fixed effects vector
sd        <- 0.4 # Residual standard deviation (when necessary)
sdg       <- 0.75 # Random Effects standard deviation

covmat    <- matrix( c(0.7, 0.3, 0.3, 0.5), ncol = 2)
scale_gam <- 2
lambda    <- 0.3

# Load estimates
lf        <- list.files(path = "results")

load( file = paste0("results/", lf[1]) )

vars <- ls()[grepl("iter", ls())]
sim  <- gsub("simulation_", "", lf[1])
sim  <- gsub(".RData", "", sim) 

vars <- gsub( paste0("_iter", sim), "", vars)

for(x in vars){
  assign( x, t( get( paste0(x, "_iter", sim) ) ) )
}

rm( list = paste0(vars, "_iter", sim) )

for(sims in lf[-1]){
  
  load( file = paste0("results/", sims) )
  
  sim  <- gsub("simulation_", "", sims)
  sim  <- gsub(".RData", "", sim) 
  
  for(x in vars){
    hv <- get( paste0(x, "_iter", sim) )
    assign( x, rbind( get(x), t(hv) ) )
  }
   
  rm( list = paste0(vars, "_iter", sim) )
  print( sims )
}

# Create plots
library(ggplot2)

df.lambda.dual <- data.frame( lambda = c(lambda.reg2.uw, lambda.reg2.w, lambda.reg2.lme4, 
                                        lambda.reg4.uw, lambda.reg4.w, lambda.reg4.lme4),
                             true.lambda = lambda,
                             method    = rep( rep( c("MCEM-unweighted", "MCEM-weighted", "lme4"), each = length(lambda.reg2.uw)), times = 2 ),
                             design    = rep( c("non-informative", "informative"), each = 3*length(lambda.reg2.uw) )
                            )

df.fixef.dual <- data.frame( fixef = c(fixef.reg2.uw[,1], fixef.reg2.w[,1], fixef.reg2.lme4[,1], 
                                       fixef.reg2.uw[,2], fixef.reg2.w[,2], fixef.reg2.lme4[,2],
                                       fixef.reg2.uw[,3], fixef.reg2.w[,3], fixef.reg2.lme4[,3],
                                       fixef.reg4.uw[,1], fixef.reg4.w[,1], fixef.reg4.lme4[,1], 
                                       fixef.reg4.uw[,2], fixef.reg4.w[,2], fixef.reg4.lme4[,2],
                                       fixef.reg4.uw[,3], fixef.reg4.w[,3], fixef.reg4.lme4[,3]),
                            true.fixef = rep( rep(beta, each = 3*nrow(fixef.reg2.uw)), times = 2 ),
                            fixef.nam = rep( rep(c("beta_0", "beta_1", "beta_2"), each = 3*nrow(fixef.reg2.uw)), times = 2 ),
                            method    = rep( rep( c("MCEM \n unweighted", "MCEM \n weighted", "lme4"), each = nrow(fixef.reg2.uw)), times = 6 ) ,
                            design = rep( c("non-informative", "informative"), each = 3 * 3 * nrow(fixef.reg2.uw) )
                            )

df.fixef.gamma <- data.frame( fixef = c(fixef.reg1.uw[,1], fixef.reg1.w[,1], fixef.reg1.lme4[,1], 
                                       fixef.reg1.uw[,2], fixef.reg1.w[,2], fixef.reg1.lme4[,2],
                                       fixef.reg1.uw[,3], fixef.reg1.w[,3], fixef.reg1.lme4[,3],
                                       fixef.reg3.uw[,1], fixef.reg3.w[,1], fixef.reg3.lme4[,1], 
                                       fixef.reg3.uw[,2], fixef.reg3.w[,2], fixef.reg3.lme4[,2],
                                       fixef.reg3.uw[,3], fixef.reg3.w[,3], fixef.reg3.lme4[,3]),
                             true.fixef = rep( rep(beta, each = 3*nrow(fixef.reg1.uw)), times = 2 ),
                             fixef.nam = rep( rep(c("beta_0", "beta_1", "beta_2"), each = 3*nrow(fixef.reg1.uw)), times = 2 ),
                             method    = rep( rep( c("MCEM \n unweighted", "MCEM \n weighted", "lme4"), each = nrow(fixef.reg1.uw)), times = 6 ),
                             design = rep( c("non-informative", "informative"), each = 3 * 3 * nrow(fixef.reg1.uw) )
                    )

df.varcov.dual <- data.frame( varcov = c(varcov.reg2.uw[,1], varcov.reg2.w[,1], varcov.reg2.lme4[,1], 
                                       varcov.reg2.uw[,2], varcov.reg2.w[,2], varcov.reg2.lme4[,2],
                                       varcov.reg2.uw[,3], varcov.reg2.w[,3], varcov.reg2.lme4[,3],
                                       varcov.reg2.uw[,4], varcov.reg2.w[,4], varcov.reg2.lme4[,4],
                                       varcov.reg4.uw[,1], varcov.reg4.w[,1], varcov.reg4.lme4[,1], 
                                       varcov.reg4.uw[,2], varcov.reg4.w[,2], varcov.reg4.lme4[,2],
                                       varcov.reg4.uw[,3], varcov.reg4.w[,3], varcov.reg4.lme4[,3],
                                       varcov.reg4.uw[,4], varcov.reg4.w[,4], varcov.reg4.lme4[,4]),
                             true.varcov = rep( rep( c(sdg^2, covmat[c(1,3,4)]), each = 3*nrow(varcov.reg2.uw)), times = 2 ),
                             varcov.nam = rep( rep(c("sigma_1", "sigma_2", "rho", "sigma_3"), each = 3*nrow(varcov.reg2.uw)), times = 2 ),
                             method    = rep( rep( c("MCEM \n unweighted", "MCEM \n weighted", "lme4"), each = nrow(varcov.reg2.uw)), times = 8 ),
                             design = rep( c("non-informative", "informative"), each = 4 * 3 * nrow(varcov.reg2.uw) )
                            )

df.varcov.gamma <- data.frame( varcov = c(varcov.reg1.uw[,1], varcov.reg1.w[,1], varcov.reg1.lme4[,1], 
                                         varcov.reg1.uw[,2], varcov.reg1.w[,2], varcov.reg1.lme4[,2],
                                         varcov.reg1.uw[,3], varcov.reg1.w[,3], varcov.reg1.lme4[,3],
                                         varcov.reg1.uw[,4], varcov.reg1.w[,4], varcov.reg1.lme4[,4],
                                         varcov.reg3.uw[,1], varcov.reg3.w[,1], varcov.reg3.lme4[,1], 
                                         varcov.reg3.uw[,2], varcov.reg3.w[,2], varcov.reg3.lme4[,2],
                                         varcov.reg3.uw[,3], varcov.reg3.w[,3], varcov.reg3.lme4[,3],
                                         varcov.reg3.uw[,4], varcov.reg3.w[,4], varcov.reg3.lme4[,4]),
                              true.varcov = rep( rep( c(sdg^2, covmat[c(1,3,4)]), each = 3*nrow(varcov.reg1.uw)), times = 2 ),
                              varcov.nam = rep( rep(c("sigma_1", "sigma_2", "rho", "sigma_3"), each = 3*nrow(varcov.reg1.uw)), times = 2 ),
                              method    = rep( rep( c("MCEM \n unweighted", "MCEM \n weighted", "lme4"), each = nrow(varcov.reg1.uw)), times = 8 ),
                              design = rep( c("non-informative", "informative"), each = 4 * 3 * nrow(varcov.reg1.uw) )
                              )

covmat_labs <- c(sigma_1 = "sigma[1]^2 == 0.5625", sigma_2 = "sigma[2]^2 == 0.7", rho = "rho == 0.3", sigma_3 = "sigma[3]^2 == 0.5")
beta_labs <- c( beta_0 = "beta[0] == 7", beta_1 = "beta[1] == -1", beta_2 = "beta[2] == 1")
col <- gray.colors(n = 2)

df.lambda.dual$lambda.nam <- "lambda"

pdf("lambda_dual_sim_chapter2.pdf", width = 12)
ggplot( data = df.lambda.dual, aes( x = method, y = lambda, fill = design)) + geom_boxplot( notch = TRUE ) + 
  facet_grid( .~ lambda.nam, labeller = as_labeller(c(lambda = "lambda == 0.3"), label_parsed), scale = "free" ) + stat_summary(fun.y = mean, col = "black", size = 3.5, shape=18, na.rm = TRUE, geom = "point", position = position_dodge(0.75), show.legend = FALSE) +
  geom_hline( yintercept = lambda, linetype = "dashed") + scale_fill_manual(name = "Design",  values = col) + 
  labs(y = "", x = "Estimation Method" ) + theme( text = element_text( size = 15), legend.position="bottom")
dev.off()  

pdf("fixef_dual_sim_chapter2.pdf", width = 12)
ggplot( data = df.fixef.dual, aes( x = method, y = fixef, fill = design)) + geom_boxplot( notch = TRUE ) + 
  facet_grid( .~ fixef.nam, labeller = as_labeller(beta_labs, label_parsed), scale = "free" ) + stat_summary(fun.y = mean, col = "black", size = 3.5, shape=18, na.rm = TRUE, geom = "point", position = position_dodge(0.75), show.legend = FALSE) +
  geom_hline( data = data.frame(true.fixef = rep(beta, 2), fixef.nam = rep(c("beta_0", "beta_1", "beta_2"), 2), design = rep( c("non-informative", "informative"), each = 3)),  
              aes(yintercept = true.fixef), linetype = "dashed") + scale_fill_manual(name = "Design",  values = col) + 
  labs(y = "", x = "Estimation Method" ) + coord_cartesian(ylim = c(-5, 17)) + theme( text = element_text( size = 15), legend.position="bottom")
dev.off()  

pdf("fixef_gamma_sim_chapter2.pdf", width = 12)
ggplot( data = df.fixef.gamma, aes( x = method, y = fixef, fill = design)) + geom_boxplot( notch = TRUE ) + 
  facet_grid( .~ fixef.nam, labeller = as_labeller(beta_labs, label_parsed), scale = "free" ) +   stat_summary(fun.y = mean, col = "black", size = 3.5, shape=18, na.rm = TRUE, geom = "point", position = position_dodge(0.75), show.legend = FALSE) +
  geom_hline( data = data.frame(true.fixef = rep(beta, 2), fixef.nam = rep(c("beta_0", "beta_1", "beta_2"), 2), design = rep( c("non-informative", "informative"), each = 3)),  
              aes(yintercept = true.fixef), linetype = "dashed") + scale_fill_manual(name = "Design",  values = col) + 
  labs(y = "", x = "Estimation Method" ) + coord_cartesian(ylim = c(-20, 40)) + theme( text = element_text( size = 15), legend.position="bottom")
dev.off()

pdf("varcov_dual_sim_chapter2.pdf", width = 12)
bounds <- boxplot.stats(df.varcov.dual$varcov)$stats[c(1, 5)]
ggplot( data = df.varcov.dual, aes( x = method, y = varcov, fill = design)) + geom_boxplot( notch = TRUE ) + 
  facet_grid( .~ varcov.nam, labeller = as_labeller(covmat_labs, label_parsed), scale = "free" ) + stat_summary(fun.y = mean, col = "black", size = 3.5, shape=18, na.rm = TRUE, geom = "point", position = position_dodge(0.75), show.legend = FALSE) +
  geom_hline( data = data.frame(true.varcov = rep(c(sdg^2, covmat[c(1,3,4)]), 2), varcov.nam = rep(c("sigma_1", "sigma_2", "rho", "sigma_3"), 2), design = rep( c("non-informative", "informative"), each = 4)),  
              aes(yintercept = true.varcov), linetype = "dashed") + scale_fill_manual(name = "Design",  values = col) + 
  labs(y = "", x = "Estimation Method" ) + coord_cartesian(ylim = c(-1, 4)) + 
  theme( text = element_text( size = 15), legend.position="bottom")
dev.off()  

pdf("varcov_gamma_sim_chapter2.pdf", width = 12)
bounds <- boxplot.stats(df.varcov.gamma$varcov)$stats[c(1, 5)]
ggplot( data = df.varcov.dual, aes( x = method, y = varcov, fill = design)) + geom_boxplot( notch = TRUE ) + 
  facet_grid( .~ varcov.nam, labeller = as_labeller(covmat_labs, label_parsed), scale = "free" ) + stat_summary(fun.y = mean, col = "black", size = 3.5, shape=18, na.rm = TRUE, geom = "point", position = position_dodge(0.75), show.legend = FALSE) +
  geom_hline( data = data.frame(true.varcov = rep(c(sdg^2, covmat[c(1,3,4)]), 2), varcov.nam = rep(c("sigma_1", "sigma_2", "rho", "sigma_3"), 2), design = rep( c("non-informative", "informative"), each = 4)),  
              aes(yintercept = true.varcov), linetype = "dashed") + scale_fill_manual(name = "Design",  values = col) + 
  labs(y = "", x = "Estimation Method" ) + coord_cartesian(ylim = bounds) + theme( text = element_text( size = 15), legend.position="bottom")
dev.off()  
