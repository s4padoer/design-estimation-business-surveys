library(mvtnorm)
library(sampling)
library(lme4)
source("optim_lmer.R")

library(wmm, lib.loc = "lib") # Load self-authored package

iter <- as.integer( Sys.getenv("var") )

# Fixed parameters
N        <- 1000 # Finite Population Size
n        <- 200
R        <- 10   # Number of MC Replications (for this job)
beta      <- c(7, -1, 1) # Fixed effects vector
sd        <- 0.4 # Residual standard deviation (when necessary)
sdg       <- 0.75 # Random Effects standard deviation
ngroups1  <- 10
ngroups2  <- 20

covmat    <- matrix( c(0.7, 0.3, 0.3, 0.5), ncol = 2)
scale_gam <- 0.5
lambda    <- 0.3

set.seed(1) # Seed for the creation of the explanatories

# Constructing a crossed random effects structure
groups1   <- sample(1:ngroups1, prob = c( rep(0.05, 5), rep(0.75/5, 5) ), size = N, replace = TRUE )
groups2   <- sample(1:ngroups2, size = N, replace = TRUE )

X         <- cbind(1, runif(N, min = -0.5, max = 0.5), runif(N) ) # Covariates
designmat <- cbind( X, model.matrix( ~ -1 + factor(groups1)), model.matrix( ~ -1 + factor(groups2) + factor(groups2):X[,2]) )

dforig        <- data.frame( x1 = X[,2], x2 = X[,3], group1 = factor(groups1), group2 = factor(groups2))

resfu <- function(res){
  q <- quantile(res, prob = c(0.25, 0.5, 0.75))
  out <- sapply(res, function(x) ifelse(x < q[1], 6, ifelse(x < q[2], 4, ifelse(x < q[3], 2, 1))))
  return(out)
}

# Initialize storage:
fixef.reg1.uw <- matrix(NA, ncol = R, nrow = 3)
fixef.reg1.w  <- matrix(NA, ncol = R, nrow = 3)
fixef.reg2.uw <- matrix(NA, ncol = R, nrow = 3)
fixef.reg2.w  <- matrix(NA, ncol = R, nrow = 3)
fixef.reg3.uw <- matrix(NA, ncol = R, nrow = 3)
fixef.reg3.w  <- matrix(NA, ncol = R, nrow = 3)
fixef.reg4.uw <- matrix(NA, ncol = R, nrow = 3)
fixef.reg4.w  <- matrix(NA, ncol = R, nrow = 3)

lambda.reg2.uw  <- numeric(R)
lambda.reg2.w    <- numeric(R)
lambda.reg2.lme4 <- numeric(R)
lambda.reg4.uw  <- numeric(R)
lambda.reg4.w    <- numeric(R)
lambda.reg4.lme4 <- numeric(R)

varcov.reg1.uw <- matrix(NA, ncol = R, nrow = 4)
varcov.reg1.w  <- matrix(NA, ncol = R, nrow = 4)
varcov.reg2.uw <- matrix(NA, ncol = R, nrow = 4)
varcov.reg2.w  <- matrix(NA, ncol = R, nrow = 4)
varcov.reg3.uw <- matrix(NA, ncol = R, nrow = 4)
varcov.reg3.w  <- matrix(NA, ncol = R, nrow = 4)
varcov.reg4.uw <- matrix(NA, ncol = R, nrow = 4)
varcov.reg4.w  <- matrix(NA, ncol = R, nrow = 4)

fixef.reg1.lme4 <- matrix(NA, ncol = R, nrow = 3)
fixef.reg2.lme4 <- matrix(NA, ncol = R, nrow = 3)
fixef.reg3.lme4 <- matrix(NA, ncol = R, nrow = 3)
fixef.reg4.lme4 <- matrix(NA, ncol = R, nrow = 3)

varcov.reg1.lme4 <- matrix(NA, ncol = R, nrow = 4)
varcov.reg2.lme4 <- matrix(NA, ncol = R, nrow = 4)
varcov.reg3.lme4 <- matrix(NA, ncol = R, nrow = 4)
varcov.reg4.lme4 <- matrix(NA, ncol = R, nrow = 4)

set.seed(iter)

for(r in 1:R){
  # Generate REs and dependent variable
  df      <- dforig
  G1      <- rnorm(ngroups1, sd = sdg)
  G2      <- rmvnorm(ngroups2, sigma = covmat)

  eta     <- designmat %*% c(beta, G1, c(G2) )

  # For Monte-Carlo expectation of the dual (as the informative design depends on the residual):
  norm.mc <- sapply(1:500, function(i){
    expect  <- eta + rnorm(N, mean = 0, sd = sd)
    expect  <- (lambda * expect + sqrt(expect^2 * lambda^2 + 1))^(1/lambda)
    return(expect)
  })
  df$expect_y_dual <- rowMeans(norm.mc, na.rm = TRUE)

  normal  <- rnorm(N, mean = eta, sd = sd)
  df$y_gamma <- rgamma(N, shape = 1/(scale_gam * eta), scale = scale_gam)
  df$y_dual  <- (lambda * normal + sqrt(normal^2 * lambda^2 + 1))^(1/lambda)
  eta <- eta[!(is.na(df$y_dual)|is.na(df$y_gamma))]
  df <- na.omit(df)

  # Create non-informative design
  ip.pps    <- inclusionprobabilities(df$x2, n)
  df$weights.pps <- 1/ip.pps

  samp.pps<- UPmidzuno(ip.pps) == 1
  dfsamp  <- df[samp.pps,]

  reg1.uw <- try( wglmm( y_gamma ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, family = Gamma(link = "inverse"), trace = TRUE, MI = 2e3 ) )
  reg1.w  <- try( wglmm( y_gamma ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, family = Gamma(link = "inverse"), weights = dfsamp$weights.pps, trace = TRUE, MI = 2e3 ) )

  reg2.uw <- try( wlmm_transform( y_dual ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, transform = "dual", trace = TRUE, MI = 2e3 ) )
  reg2.w  <- try( wlmm_transform( y_dual ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, transform = "dual", weights = dfsamp$weights.pps, trace = TRUE, MI = 2e3 ) )

  reg1.lme4 <- try( glmer( y_gamma ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, family = Gamma(link = "inverse")) )
  reg2.lme4 <- try( optim_lmer( y_dual ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, transform = "dual") )
  
  eps_gamma <- df$y_gamma - 1/eta
  eps_dual  <- df$y_dual - df$expect_y_dual

  # Create informative designs
  ip.ups_gamma <- inclusionprobabilities(resfu(eps_gamma), n)
  df$weights.ups_gamma <- 1/ip.ups_gamma

  ip.ups_dual<- inclusionprobabilities(resfu(eps_dual), n)
  df$weights.ups_dual <- 1/ip.ups_dual

  samp.ups <- UPmidzuno(ip.ups_gamma) == 1
  dfsamp <- df[samp.ups, ]

  reg3.uw  <- try( wglmm( y_gamma ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, family = Gamma(link = "inverse"), trace = TRUE, MI = 2e3 ) )
  reg3.w   <- try( wglmm( y_gamma ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, family = Gamma(link = "inverse"), weights = dfsamp$weights.ups_gamma, trace = TRUE, MI = 2e3 ) )

  reg3.lme4 <- try( glmer( y_gamma ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, family = Gamma(link = "inverse")) )
  
  samp.ups <- UPmidzuno(ip.ups_dual) == 1
  dfsamp <- df[samp.ups, ]

  reg4.uw    <- try( wlmm_transform( y_dual ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, transform = "dual", trace = TRUE, MI = 2e3 ) )
  reg4.w     <- try( wlmm_transform( y_dual ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, transform = "dual", weights = dfsamp$weights.ups_dual, trace = TRUE, MI = 2e3 ) )

  reg4.lme4 <- try( optim_lmer( y_dual ~ x1 + x2 + (1|group1) + (1 + x1 | group2), data = dfsamp, transform = "dual") )
  
  # Store estimates
  if(class(reg1.uw) != "try-error"){
    fixef.reg1.uw[,r] <- reg1.uw$coef
    varcov.reg1.uw[,r] <- c(reg1.uw$VarCov[[2]][1], reg1.uw$VarCov[[1]][c(1,3,4)])
  }
  if(class(reg1.w) != "try-error"){
    fixef.reg1.w[,r] <- reg1.w$coef
    varcov.reg1.w[,r] <- c(reg1.w$VarCov[[2]][1], reg1.w$VarCov[[1]][c(1,3,4)])
  }
  if(class(reg1.lme4) != "try-error"){
    hv <- lapply(VarCorr(reg1.lme4), as.matrix)
    fixef.reg1.lme4[,r] <- fixef(reg1.lme4)
    varcov.reg1.lme4[,r] <- c(hv[[2]][1], hv[[1]][c(1,3,4)])
  }
  
  if(class(reg2.uw) != "try-error"){
    fixef.reg2.uw[,r] <- reg2.uw$model$coef
    varcov.reg2.uw[,r] <- c(reg2.uw$model$VarCov[[2]][1], reg2.uw$model$VarCov[[1]][c(1,3,4)])
    lambda.reg2.uw[r] <- reg2.uw$model$lambda
  }
  if(class(reg2.w) != "try-error"){
    fixef.reg2.w[,r] <- reg2.w$model$coef
    varcov.reg2.w[,r] <- c(reg2.w$model$VarCov[[2]][1], reg2.w$model$VarCov[[1]][c(1,3,4)])
    lambda.reg2.w[r] <- reg2.w$model$lambda
  }
  if(class(reg2.lme4) != "try-error"){
    hv <- lapply(VarCorr(reg2.lme4$model), as.matrix)
    fixef.reg2.lme4[,r] <- fixef(reg2.lme4$model)
    varcov.reg2.lme4[,r] <- c(hv[[2]][1], hv[[1]][c(1,3,4)])
    lambda.reg2.lme4[r] <- reg2.lme4$lambda
  }
  
  if(class(reg3.uw) != "try-error"){
    fixef.reg3.uw[,r] <- reg3.uw$coef
    varcov.reg3.uw[,r] <- c(reg3.uw$VarCov[[2]][1], reg3.uw$VarCov[[1]][c(1,3,4)])
  }
  if(class(reg3.w) != "try-error"){
    fixef.reg3.w[,r] <- reg3.w$coef
    varcov.reg3.w[,r] <- c(reg3.w$VarCov[[2]][1], reg3.w$VarCov[[1]][c(1,3,4)])
  }
  if(class(reg3.lme4) != "try-error"){
    hv <- lapply(VarCorr(reg3.lme4), as.matrix)
    fixef.reg3.lme4[,r] <- fixef(reg3.lme4)
    varcov.reg3.lme4[,r] <- c(hv[[2]][1], hv[[1]][c(1,3,4)])
  }
  
  if(class(reg4.uw) != "try-error"){
    fixef.reg4.uw[,r] <- reg4.uw$model$coef
    varcov.reg4.uw[,r] <- c(reg4.uw$model$VarCov[[2]][1], reg4.uw$model$VarCov[[1]][c(1,3,4)])
    lambda.reg4.uw[r] <- reg4.uw$model$lambda
  }
  if(class(reg4.w) != "try-error"){
    fixef.reg4.w[,r] <- reg4.w$model$coef
    varcov.reg4.w[,r] <- c(reg4.w$model$VarCov[[2]][1], reg4.w$model$VarCov[[1]][c(1,3,4)])
    lambda.reg4.w[r] <- reg4.w$model$lambda
  }
  if(class(reg4.lme4) != "try-error"){
    hv <- lapply(VarCorr(reg4.lme4$model), as.matrix)
    fixef.reg4.lme4[,r] <- fixef(reg4.lme4$model)
    varcov.reg4.lme4[,r] <- c(hv[[2]][1], hv[[1]][c(1,3,4)])
    lambda.reg4.lme4[r] <- reg4.lme4$lambda
  }
}

safe <- c( ls()[grepl("fixef.", ls())], ls()[grepl("lambda.", ls())], ls()[grepl("varcov.", ls())] )

for(x in safe){
  assign( paste0(x, "_iter", iter), get(x) )
}

save( list = paste0(safe, "_iter", iter), file = paste0("results/simulation_", iter, ".RData") )