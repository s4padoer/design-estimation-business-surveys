###################################################################################################
# Bivariate density estimation on total sales three fiscal years ago and last fiscal year (BEEPS) #
###################################################################################################

var <- as.integer( Sys.getenv("var") )
require(Rcpp)
require(RcppArmadillo)
require(mclust) # Gaussian Mixtures
require(ks) # Multivariate Kernel Density

path_application <- "application_beeps/"
setwd("..")
setwd("chapter4")
source("som_simplex.R")
source("distributions_som_simplex.R")

setwd("..")
setwd(path_application)

load("AppliedLoans.RData")
beeps_panel$id <- 1:nrow(beeps_panel)
mat <- beeps_panel[,c("d2", "n3", "weights", "id")]
mat <- as.matrix(na.omit(mat))
mat <- mat[(mat[,"d2"] > 0) & (mat[,"n3"] > 0),] # Remove mass point
cor( mat[,"d2"], beeps_panel$l1[mat[,"id"]]) # l1 was number of full time employees - which is a stratifier and correlated with
                                             # total sales: hence, the design may be considered informative
# 0.3495

cor( mat[,"weights"], beeps_panel$l1[mat[,"id"]])
# -0.1554 - The correlation indicates that firm size is indeed a stratifier
mat <- mat[,1:3]
# Grid for density estimation:
n3 <- seq( from = -1e3, to = quantile(mat[,"n3"], prob = 0.9 ), length.out = 2000 ) 
d2 <- seq( from = -1e3, to = quantile(mat[,"d2"], prob = 0.9 ), length.out = 2000 ) 
grid <- as.matrix(expand.grid(d2, n3))
colnames(grid) <- c("d2", "n3")

# # Gaussian Mixtures - is run once and then stored for the plots later on
# gmm <- densityMclust(mat[,1:2])
# dens_gmm <- predict(gmm, newdata = grid)
# 
# # Kernel density
# ks <- kde(mat[,1:2], gridsize = nrow(mat))
# dens_ks <- predict(ks, x = grid)
# # Weighted Kernel density - scaling such that the sum of weights again equals nrow(mat) (cf. description of kde)
# ks_wt <- kde(mat[,1:2], gridsize = nrow(mat), w = nrow(mat) * mat[,3]/sum(mat[,3]) )
# dens_ks_wt <- predict(ks_wt, x = grid)
# save( list = c("grid", "d2", "n3", "mat", "dens_ks", "dens_ks_wt", "dens_gmm"), file = "beeps_pre_density.RData" )

# SOM-based: Here, we take the average of 100 estimates because of the stochastic optimization
B <- 1

count       <- 0
count_wt    <- 0
dens_som    <- numeric(nrow(grid))
dens_som_wt <- numeric(nrow(grid))

set.seed(var)

for(b in 1:B){
  rep <- 0
  som_dist <- try( gsom_simplex( mat[,1:2], max_nodes = 90, Niter = 120, temperature = 3, mini.batch = 90 ) )
  
  while(class(som_dist) == "try-error"){
    rep <- rep+1
    som_dist <- try( gsom_simplex( mat[,1:2], max_nodes = 90, Niter = 120, temperature = 3, mini.batch = 90 ) )
    if( rep > 19){
      break
    }
  }
  
  if(class(som_dist)!="try-error"){
    est_dist <- distribution_som(som_dist)
    count <- count+1
    hv <- est_dist$jointdens(grid)
    dens_som <- dens_som + hv
  }
  
  ############### Weighted Version ####################
  rep <- 0
  som_dist <- try( gsom_simplex( mat[,1:2], weights = mat[,3], max_nodes = 90, Niter = 120, temperature = 3, mini.batch = 90 ) )
  
  while(class(som_dist) == "try-error"){
    rep <- rep+1
    som_dist <- try( gsom_simplex( mat[,1:2], weights = mat[,3], max_nodes = 90, Niter = 120, temperature = 3, mini.batch = 90 ) )
    if( rep > 29){
      break
    }
  }
  
  if(class(som_dist)!="try-error"){
    est_dist <- distribution_som(som_dist)
    count_wt <- count_wt+1
    hv <- est_dist$jointdens(grid)
    dens_som_wt <- dens_som_wt + hv
  }
}

assign( paste0("dens_som_sim", var), dens_som )
assign( paste0("dens_som_wt_sim", var), dens_som_wt )
assign( paste0("count_sim", var), count )
assign( paste0("count_wt_sim", var), count_wt )

save( list = c(paste0("dens_som_sim", var), paste0("dens_som_wt_sim", var),
		paste0("count_sim", var), paste0("count_wt_sim", var) ), 
      file = paste0("results_density/sim_", var, ".RData") )



