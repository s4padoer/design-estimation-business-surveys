###############################################
# Merge results from BEEPS density estimation #
###############################################

# Load data
lf <- list.files("results_density")
load( paste0("results_density/", lf[1]) )

sim <- gsub("_", "", gsub(".RData", "", lf[1]) )

assign("count", get(paste0("count_", sim)))
assign("count_wt", get(paste0("count_wt_", sim)))
assign("dens_som", get(paste0("dens_som_", sim)))
assign("dens_som_wt", get(paste0("dens_som_wt_", sim)))

rm( list = ls()[grepl(sim, ls())])
gc()

for(fs in lf[-1]){
  load( paste0("results_density/", fs) )
  sim <- gsub("_", "", gsub(".RData", "", fs) )
  
  assign("count", count + get(paste0("count_", sim)))
  assign("count_wt", count_wt + get(paste0("count_wt_", sim)))
  assign("dens_som", dens_som + get(paste0("dens_som_", sim)))
  assign("dens_som_wt", dens_som_wt + get(paste0("dens_som_wt_", sim)))
  
  rm( list = ls()[grepl(sim, ls())])
  gc()
  print(fs)
}

# Take average (not done before)
dens_som <- dens_som/count
dens_som_wt <- dens_som_wt/count_wt

# Load results for GLMM and Kernel density
load("beeps_pre_density.RData")

# Weighted mini-batch did not work out in simulation, so give it another try
setwd("..")
setwd("chapter4")
source("som_simplex.R")
source("distributions_som_simplex.R")
set.seed(1234) 
rep <- 0
som_dist <- try( gsom_simplex( mat[,1:2], weights = mat[,3], max_nodes = 90, Niter = 100, temperature = 3, mini.batch = 90 ) )

while(class(som_dist) == "try-error"){
  rep <- rep+1
  som_dist <- try( gsom_simplex( mat[,1:2], weights = mat[,3], max_nodes = 90, Niter = 100, temperature = 3, mini.batch = 90 ) )
  if( rep > 29){
    break
  }
}

# Get density estimator from weighted SOM
est_dist <- distribution_som(som_dist)
dens_som_wt <- est_dist$jointdens(grid)

setwd("..")
setwd("application_beeps")
save( list = c("grid", "d2", "n3", "mat", "dens_ks", "dens_ks_wt", "dens_gmm", "dens_som", "dens_som_wt"), file = "beeps_density.RData" )

# Create plots
library(plotly)
load("beeps_density.RData")

cor(mat)

# delete those points - range of plot
ind <- grid[,1] <= 3e6 & grid[,2] <= 2e6
ind_d2 <- d2 <= 3e6
ind_n3 <- n3 <= 2e6

rm(grid, mat)
gc()

base_fig <- plot_ly( x = d2[ind_d2], y = n3[ind_n3]) %>%
  layout( scene = list( xaxis = list(title = "d2", size = 15, tickfont = 15), 
                        yaxis = list(title = "n3", size = 15, tickfont = 15), 
                        zaxis = list(title = "Density", size = 15, tickfont = 15) ) ) 


fig1 <- base_fig %>%
  layout( scene = list(yaxis = list( range = c(-1e3,2e6)),  xaxis = list( range = c(-1e3,3e6)), 
                       zaxis = list( range = c(0, 1.5*max(dens_ks)))) ) %>%
  add_surface( z = matrix( dens_ks[ind], ncol = sum(ind_n3)), showscale = TRUE,
               colorscale = list(c(0,1), c("tan", "blue")), colorbar = list(title = "KDE", tickfont = 15, size = 15) ) %>%
  add_surface( z = matrix( dens_gmm[ind], ncol = sum(ind_n3) ), showscale = TRUE,
               colorscale = list(c(0,1), c("green", "red")), colorbar = list(title = "GMM", tickfont = 15, size = 15) ) %>%
  add_surface( z = matrix( dens_som[ind], ncol = sum(ind_n3) ),  colorbar = list(title = "SOM", tickfont = 15, size = 15) )

fig1

rm(fig1)
gc()

# Contour plot
fig2a <- base_fig %>%
  layout( scene = list(yaxis = list( range = c(-1e3,2e6)),  xaxis = list( range = c(-1e3,3e6))) ) %>%
  add_contour( z = matrix( dens_ks[ind], ncol = sum(ind_n3)), showscale = FALSE,
               colorscale = list(c(0,1), c("tan", "blue")), colorbar = list(title = "KDE") )

fig2b <- base_fig %>%
  layout( scene = list(yaxis = list( range = c(-1e3,2e6)),  xaxis = list( range = c(-1e3,3e6))) ) %>%
  add_contour( z = matrix( dens_gmm[ind], ncol = sum(ind_n3) ), showscale = FALSE,
               colorscale = list(c(0,1), c("green", "red")), colorbar = list(title = "GMM") ) 

fig2c <- base_fig %>%
  layout( scene = list(yaxis = list( range = c(-1e3,2e6)),  xaxis = list( range = c(-1e3,3e6))) ) %>%
  add_contour( z = matrix( dens_som[ind], ncol = sum(ind_n3) ),  showscale = FALSE, 
               colorbar = list(title = "SOM") )

fig2 <- subplot(fig2a, fig2b, fig2c) 
rm(fig2a, fig2b, fig2c)
gc()

fig2

rm(fig2)
gc()

# Weighted density
fig3 <- base_fig %>%
  layout( scene = list(yaxis = list( range = c(-1e3,2e6)),  xaxis = list( range = c(-1e3,3e6)) ) ) %>%
  add_surface( z = matrix( dens_ks_wt[ind], ncol = sum(ind_n3)), showscale = TRUE,
               colorscale = list(c(0,1), c("tan", "blue")), colorbar = list(title = "KDE (wtd)") ) %>%
  add_surface( z = matrix( dens_som_wt[ind], ncol = sum(ind_n3)), showscale = TRUE,
               colorscale = list(c(0,1), c("orange", "violet")), colorbar = list(title = "SOM (wtd)") ) %>%
  add_surface( z = matrix( dens_som[ind], ncol = sum(ind_n3) ),  colorbar = list(title = "SOM") )

fig3

rm(fig3)
rm(dens_gmm, dens_ks, dens_ks_wt, dens_som, dens_som_wt, ind)
gc()


