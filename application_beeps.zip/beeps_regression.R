########################################
# Estimate logit regression with wglmm #
########################################

# Run survey-weighted GLMM on chosen regressions
iter <- as.integer( Sys.getenv("var") )

library(wmm, lib.loc = "~s4padoer/Diss/phd_submission/lib")

load("AppliedLoans.RData")
set.seed(iter)
#########

reg1f_wglmm <- try( wglmm( finance_high_obstacle ~ female_topmanager + collateral_required + b7 + l1 + 
                             loan_rejected + age_firm + invest_rd + sales_growth + f1 + d3d + (1|a4b) + (1|country), 
                data = dat, family = binomial(), MI = 700, trace = FALSE ) )

coef_reg1f_wglmm <- reg1f_wglmm$coef
resid_reg1f_wglmm <- reg1f_wglmm$residuals[["resid"]]
varre_reg1f_wglmm <- reg1f_wglmm$VarCov
rm(reg1f_wglmm)
gc()
######
reg1f_2_wglmm <- try( wglmm( finance_high_obstacle ~ female_topmanager + collateral_required +  b7 + l1 + age_firm + 
                               invest_rd + sales_growth + f1 + d3d + (1|a4b) + (1|country), 
                  data = dat2, family = binomial(), MI = 700, trace = FALSE ) )

coef_reg1f_2_wglmm <- reg1f_2_wglmm$coef
resid_reg1f_2_wglmm <- reg1f_2_wglmm$residuals[["resid"]]
varre_reg1f_2_wglmm <- reg1f_2_wglmm$VarCov
rm(reg1f_2_wglmm)
gc()
#######

reg3f_wglmm <- try(wglmm( pessimistic_approval ~ female_topmanager + collateral_required + b7 + l1 + age_firm + 
                            invest_rd + sales_growth + f1 + d3d + finance_high_obstacle  + (1|a4b) + (1|country), 
                data = dat3, family = binomial(), MI = 700, trace = FALSE ) )

coef_reg3f_wglmm <- reg3f_wglmm$coef
resid_reg3f_wglmm <- reg3f_wglmm$residuals[["resid"]]
varre_reg3f_wglmm <- reg3f_wglmm$VarCov
rm(reg3f_wglmm)
gc()
#######

reg4f_wglmm <- try( wglmm( loan_rejected ~ female_topmanager + collateral_required + b7 + l1 + age_firm +
                             invest_rd + sales_growth + f1 + d3d  + (1|a4b) + (1|country), 
                data = dat, family = binomial(), MI = 700, trace = FALSE ) )

coef_reg4f_wglmm <- reg4f_wglmm$coef
resid_reg4f_wglmm <- reg4f_wglmm$residuals[["resid"]]
varre_reg4f_wglmm <- reg4f_wglmm$VarCov
rm(reg4f_wglmm)
gc()

safe <- ls()[grepl("wglmm", ls())]

for(x in safe){
  assign( paste0(x, "_sim", iter), get(x) )
}

save( list = paste0(safe, "_sim", iter), file = paste0("results_regression/sim", iter, ".RData") )
