library(foreign)
library(haven)
beeps_panel <- read_dta("/home/doerr/Schreibtisch/Studium/Dissertation/pums/enterprise_survey_worldbank/BEEPS_Panel_2002_2005_2009_19 Aug 2010.dta")

colnames(beeps_panel)
table(beeps_panel$year)
table(beeps_panel$a2, beeps_panel$a1)

# Derive Country Codes
code <- c(44, 50, 51, 52, 54, 55, 58, 59, 60, 61, 63, 64, 65, 66, 67, 68, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80)
names(code) <- c("Albania", "Belarus", "Georgia", "Tajikistan", "Ukraine", "Uzbekistan", "Russia", "Poland", 
                 "Romania", "Serbia and Montenegro", "Moldova", "Bosnia-Herzegovina", "Azerbaijan", "North Macedonia", "Armenia", 
                 "Kyrgyz Republic", "Estonia", "Czech-Republic", "Hungary", "Latvia", "Lithuania", "Slovak Republic",
                 "Slovenia", "Bulgaria", "Croatia", "Montenegro")

beeps_panel <- beeps_panel[beeps_panel$a1 != 62,] # Could not identify country code 62
# Add Montenegro to Serbia
code["Montenegro"]
code["Serbia and Montenegro"]
beeps_panel$a1[beeps_panel$a1 == 80] <- 61
beeps_panel$country <- factor( beeps_panel$a1, levels = code[-26], labels = names(code)[-26] )
beeps_panel <- beeps_panel[,-which(colnames(beeps_panel) == "a1")]
beeps_panel$a2 <- tolower(beeps_panel$a2) # adjust letters

beeps_panel$d2[beeps_panel$d2 == -9] <- NA
beeps_panel$n3[beeps_panel$n3 == -9] <- NA

beeps_panel$sales_growth <- sqrt( beeps_panel$d2 / beeps_panel$n3 ) - 1  # From 3 years ago to last year, i.e. two years (for geometric mean)

# Switch LCU to USD (period average exchange rate, world bank, download on 15.03.2020) 
exchange_dat <- read.table( file = "/home/doerr/Schreibtisch/Studium/Dissertation/pums/enterprise_survey_worldbank/worldbank_exchange_rate_edited.csv",
                            header = TRUE, sep = ",")

beeps_panel <- merge(beeps_panel, exchange_dat, by = c("country", "year") )

# Variables in LCU last fiscal year
vars <- c("j7b", "ECAj14a", "n2a", "n2i", "n2b", "n2c", "c9b", "d2", "ECAd8a", "ECAw2")
beeps_panel[,vars] <- sapply(vars, function(x) beeps_panel[,x] / beeps_panel$exchange_last_fsc_year )

# Variables in LCU three fiscal years ago
vars <- c( "n3")
beeps_panel[,vars] <- sapply(vars, function(x) beeps_panel[,x] / beeps_panel$exchange_three_fsc_year_ago )

# Possibly relevant variables for a regression model
# a0 Manufacturing, Services or Core => more details in a4a
# a3 Size of locality
# a4a Industry sampling sector
# a6a Size of firm
# a9 Financial statements seperately prepared 
# b1 legal status of firm
# b2(a-d) Shares of firm 
# b4 Exist female owners?
# b5 Years of operation
# b6b formally registered
# b7 years of experience of top manager
# ECAb7a top manager female?
# d1a3 share of top product on total sales
# d2 total annual sales
# d3(a-c) share of exports
# ECAd8a total value of exports
# ECAq64(a-c) Pressure from competitors to reduce production costs
# ECAq53 received subsidies
# ECAo1 new products/ series in last 3 years
# ECAo3 investment in new products/ series in last 3 years
# ECAo12 disgraded a product/ series
# f1 % capacity utilization of establishment (last fiscal year)
# k9 financial institution that granted last loan
# k11 value of credit at time of approval
# k13 Required collateral for most recent loan/ credit
# k16 application to credit (last fiscal year)
# k17 main reason not to apply
# k18a rejected loans
# k30 Access to finance major obstacle for establishment?
# l5 female permanent full-time employees
# l6 no of full time employees overall
# n3 total annual sales (three fiscal years ago)
# d2 last years annual sales

beeps_panel$k13[beeps_panel$k13 == -9] <- NA # Collateral required for latest loan
beeps_panel$collateral_required <- beeps_panel$k13 == 1
beeps_panel$d3d <- beeps_panel$d3b + beeps_panel$d3c # share exports
beeps_panel$a4b <- factor(beeps_panel$a4b, levels = attributes(beeps_panel$a4b)$labels)

beeps_panel$k18a[beeps_panel$k18a == -9]  <- NA               # Those that had a loan rejected or approved (remove NA)
beeps_panel$loan_rejected <- beeps_panel$k18a == 1
beeps_panel$finance_high_obstacle <- beeps_panel$k30 > 2      # Is access to finance high obstacle?
beeps_panel$ECAb7a[beeps_panel$ECAb7a == -9] <- NA
beeps_panel$female_topmanager <- beeps_panel$ECAb7a == 1      # Top manager female?
beeps_panel$b4[beeps_panel$b4 == -9] <- NA                    # Female owner
beeps_panel$female_owner <- beeps_panel$b4 == 1               # Do female owners exist?
beeps_panel$b7[beeps_panel$b7 == -9] <- NA                    # Years of experience of top manager
beeps_panel$f1[beeps_panel$f1 == -9] <- NA                    # % capacity use
beeps_panel$ECAo3[beeps_panel$ECAo3 == -9] <- NA              # Investment in R & D?
beeps_panel$invest_rd <- beeps_panel$ECAo3 == 1
beeps_panel$k16[beeps_panel$k16 == -9] <- NA
beeps_panel$b5[beeps_panel$b5 == -9] <- NA 
beeps_panel$age_firm <- (beeps_panel$year - beeps_panel$b5)   # Age of firm in last fiscal year

AppliedLoans <- beeps_panel[beeps_panel$k16 == 1, ]           # Firms that applied for loans

save( list = c("exchange_dat", "beeps_panel", "AppliedLoans"), file = "AppliedLoans.RData")

