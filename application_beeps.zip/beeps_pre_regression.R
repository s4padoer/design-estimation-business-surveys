#####################################################################################################
# Pre-analysis/ choice of the regression model (via lme4) that is chosen to be estimated with wglmm #
#####################################################################################################
# Subset of BEEPS Panel data of firms that applied last fiscal year for a loan or credit

load("AppliedLoans.RData")

###############################################
# Variables:
# number of permanent full-time employees last fiscal year
# finance_high_obstacle: Indicator whether access to finance is considered to be a high or major obstacle for the firm
# loan_rejected: Indicator whether the firm was rejected a loan last fiscal year
# female_topmanager: Indicator whether the top manager is female
# sales_growth: Average growth of returns of sales between three fiscal years ago and last fiscal year (in LCU)
# invest_rd: Indicator whether the firm invested (directly or indirectly) in research and development last year
# a4b: Firms industry sector
# b7: Years of experience of top manager
# female_owner: Indicator whether at least one of the owners is female
# f1: Percentage of capacity of the plants used last year
# d3d: Direct and indirect share of exports of sales

vars <- c("k16", "l1", "finance_high_obstacle", "loan_rejected",  "collateral_required", "age_firm", "female_topmanager", "sales_growth", "invest_rd", "a4b", 
          "b7", "female_owner", "f1", "d3d", "country", "year", "weights")
dat  <- AppliedLoans[,vars]

dat  <- dat[is.finite(dat$sales_growth),]
dat  <- na.omit(dat[,-which(colnames(dat) %in% c("weights"))]) 
# There is only one observation with a weight -- remove therefore weights from analysis

# Drop those countries / industry sector levels that are not contained in the subset
dat$country <- droplevels(dat$country)
dat$a4b <- droplevels(dat$a4b)

# Check correlations of explanatories
cor(model.matrix( ~ -1 + loan_rejected + female_topmanager + collateral_required + b7 + l1 + female_owner + sales_growth + invest_rd + f1 + d3d, data = dat))
# Existence of female owner is relatively highly correlated with female top-manager: Perhaps leave one out in analysis due to collinearity

##############################################
# Pre-analysis for model selection

library(lme4)
library(MASS)
library(evd)

# Try to find relevant fixed effects
#########
reg1a <- glmer( finance_high_obstacle ~ female_owner*collateral_required + female_topmanager * b7 + 
                  female_topmanager:collateral_required + l1 + loan_rejected + age_firm + 
                  invest_rd + sales_growth + f1 + d3d + (1|a4b) + (1|country), 
               data = dat, family = binomial() )

res <- residuals(reg1a, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

summary(reg1a)
BIC(reg1a)
logLik(reg1a)
var(res)

# Leave female owner out
reg1b <- glmer( finance_high_obstacle ~ female_topmanager * b7 + female_topmanager:collateral_required + l1 + 
                  loan_rejected + age_firm + invest_rd + sales_growth + f1 + d3d  + (1|a4b) + (1|country), 
                data = dat, family = binomial() )

res <- residuals(reg1b, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

summary(reg1b)
BIC(reg1b) # lower than reg1a => leave one of female variables out?
logLik(reg1b) # Only marginally lower than previously
var(res) # Only marginally worse than previously

# No interaction term between gender of top manager and years of experience
reg1c <- glmer( finance_high_obstacle ~ female_owner*collateral_required + female_topmanager + b7 + l1 + 
                  loan_rejected + age_firm + invest_rd + sales_growth + f1 + d3d  + (1|a4b) + (1|country), 
                data = dat, family = binomial() )

res <- residuals(reg1c, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

summary(reg1c)
BIC(reg1c) # lower than reg1b => leave interaction out
logLik(reg1c) # Only marginally better than previously
var(res) # Only marginally better than previously

reg1d <- glmer( finance_high_obstacle ~ female_owner*collateral_required + b7 + l1 + loan_rejected + age_firm +
                  invest_rd + sales_growth + f1 + d3d  + (1|a4b) + (1|country), 
                data = dat, family = binomial() )

res <- residuals(reg1d, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

summary(reg1d)
BIC(reg1d) # lower than reg1c => possibly leave female_topmanager out
logLik(reg1d) # Only marginally worse than previously
var(res) # Only marginally worse than previously


reg1e <- glmer( finance_high_obstacle ~ female_topmanager *collateral_required + b7 + l1 + loan_rejected + age_firm +
                  invest_rd + sales_growth + f1 + d3d + (1|a4b) + (1|country), 
                data = dat, family = binomial() )

res <- residuals(reg1e, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

summary(reg1e)
BIC(reg1e) # higher than reg1d => leave better female_topmanager out. But if there exist female owners, the ownership 
# can still be mixed => confounding of analysis
logLik(reg1e) # Also worse than reg1d (but only a little)
var(res) # The same

# Interaction collateral and topmanager
reg1f <- glmer( finance_high_obstacle ~ female_topmanager + collateral_required + b7 + l1 + loan_rejected + age_firm +
                  invest_rd + sales_growth + f1 + d3d + (1|a4b) + (1|country), 
                data = dat, family = binomial() )

res <- residuals(reg1f, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

summary(reg1f)
BIC(reg1f) # lower than reg1e => leave interaction out
logLik(reg1f) # worse than reg1e (but only a little)
var(res) # The same

#######
# Of course a firm with a rejected loan/ credit perceives the access to finance worse. What about all firms overall?
#######
vars <- c("k16", "l1", "finance_high_obstacle", "collateral_required", "loan_rejected", "collateral_required", 
          "age_firm", "female_topmanager", "sales_growth", "invest_rd", "a4b", 
          "b7", "female_owner", "f1", "d3d", "country", "year", "weights")
dat2  <- beeps_panel[,vars]
dat2$k16[dat2$k16 == -9] <- NA
dat2  <- dat2[is.finite(dat2$sales_growth),]
dat2  <- na.omit(dat2[,-which(colnames(dat2) %in% c("weights", "loan_rejected"))]) 
# If NAs from Loan rejected is removed, we get exactly the same firms (those that did not apply for a loan could not
# be rejected, hence NA)

# Drop those countries / industry sectors that are not contained in the subset
dat2$country <- droplevels(dat2$country)
dat2$a4b <- droplevels(dat2$a4b)

reg1f_2 <- glmer( finance_high_obstacle ~ female_topmanager + collateral_required + b7 + l1 + age_firm + 
                    invest_rd + sales_growth + f1 + d3d + (1|a4b) + (1|country), 
                data = dat2, family = binomial() )

res <- residuals(reg1f_2, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

summary(reg1f_2)
# Obviously, no role of gender neither

# Do female top manager apply more rarely to loans?
vars <- c("k17", "l1", "finance_high_obstacle", "loan_rejected",  "collateral_required", 
          "age_firm", "female_topmanager", "sales_growth", "invest_rd", "a4b", 
          "b7", "female_owner", "f1", "d3d", "country", "year", "weights")
dat3  <- beeps_panel[beeps_panel$k16 == 2,vars] # Those that did not apply for a loan
dat3  <- dat3[is.finite(dat3$sales_growth),]
dat3$pessimistic_approval <- dat3$k17 == 7 # Did not try to apply for loan because too pessimistic about approval
dat3  <- na.omit(dat3[,-which(colnames(dat3) %in% c("weights", "loan_rejected"))]) 
# If NAs from Loan rejected is removed, we get exactly the same firms (those that did not apply for a loan could not
# be rejected, hence NA)

reg3d <- glmer( pessimistic_approval ~ female_owner + collateral_required + b7 + l1 + age_firm + 
                  invest_rd + sales_growth + f1 + d3d + finance_high_obstacle  + (1|a4b) + (1|country), 
                data = dat3, family = binomial() )
summary(reg3d)
# This is interesting: Women-owned firms are less pessimistic (but not significantly)
res <- residuals(reg3d, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

reg3f <- glmer( pessimistic_approval ~ female_topmanager + collateral_required + b7 + l1 + age_firm + 
                  invest_rd + sales_growth + f1 + d3d + finance_high_obstacle  + (1|a4b) + (1|country), 
               data = dat3, family = binomial() )

summary(reg3f)
res <- residuals(reg3f, type = "response")
beta <- sqrt(mean(res^2)*6)/pi
y <- qlogis(probs, scale = beta)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)

#######
# Now check determinants of loan rejection
reg4d <- glmer( loan_rejected ~ female_owner + collateral_required + b7 + l1 + age_firm + 
                  invest_rd + sales_growth + f1 + d3d  + (1|a4b) + (1|country), 
                data = dat, family = binomial() )

summary(reg4d)
BIC(reg4d)
logLik(reg4d)

reg4f <- glmer( loan_rejected ~ female_topmanager + collateral_required + b7 + l1 + age_firm + 
                  invest_rd + sales_growth + f1 + d3d  + (1|a4b) + (1|country), 
                data = dat, family = binomial() )

res <- residuals(reg4f, type = "response")
y <- qgumbel(probs, scale = sqrt(mean(res^2)*6)/pi)
x <- quantile(res, probs)
plot(x,y)
abline(a = 0, b = 1, col = 2)
summary(reg4f)
BIC(reg4f) # Only slightly worse than reg4d (still, confounding problem)
logLik(reg4f) # worse than reg4d

# Hence, for testing wglmm, models reg1f, reg1f_2, reg3f and reg4f are the most interesting ones
save(list = c("beeps_panel", "AppliedLoans", "exchange_dat", "dat", "dat2", "dat3"), file = "AppliedLoans.RData")
save(list = c("reg1f", "reg1f_2", "reg3f", "reg4f"), file = "lme4_regressions.RData" )
