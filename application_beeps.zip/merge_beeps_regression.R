#########################
# Merge regression data #
#########################
# Load the 100 regression estimates
library(lme4)
lf <- list.files("results_regression")

load( paste0("results_regression/", lf[1]) )
sim <- gsub(".RData", "", lf[1])
vars <- ls()[grepl(sim, ls())]
vars <- gsub( paste0("_", sim), "", vars)

for( x in vars ){
  if(grepl("coef", x)){
    assign(x, t( get( paste0(x, "_", sim) ) ) )
  }else if(grepl("varre", x)){
    assign(x, unlist( get( paste0(x, "_", sim) ) ) )
  }else if(grepl("resid", x)){
    assign( paste0("unconditional_", x), t( get( paste0(x, "_", sim) )[[1]] ) )
    assign( paste0("conditional_", x), t( get( paste0(x, "_", sim) )[[3]] ) )
  }
}

rm( list = paste0(vars, "_", sim) )

for(lfs in lf[-1]){
  sim <- gsub(".RData", "", lfs) 
  load( paste0("results_regression/", lfs) )
  
  for( x in vars ){
    if(grepl("coef", x)){
      assign(x, rbind( get(x), t( get( paste0(x, "_", sim) ) ) ) )
    }else if(grepl("varre", x)){
      assign(x, rbind( get(x) , unlist( get( paste0(x, "_", sim) ) ) ) )
    }else if(grepl("resid", x)){
      assign( paste0("unconditional_", x), rbind( get(paste0("unconditional_", x)), 
                                                 t( get( paste0(x, "_", sim) )[[1]] ) ) )
      assign( paste0("conditional_", x), rbind( get(paste0("conditional_", x)), 
                                                t( get( paste0(x, "_", sim) )[[3]] ) ) )
    }
  }
  rm( list = paste0(vars, "_", sim) )
}

# Load results from lme4
load("lme4_regressions.RData")

# Create tables
library(ggplot2)
# Add stars to signifcant parameters
stars_reg1f <- sapply( summary(reg1f)$coefficients[,4], function(x) ifelse(x < 0.01, "***", ifelse(x < 0.05, "**", ifelse(x < 0.1, "*", ""))) )
stars_reg1f_2 <- sapply( summary(reg1f_2)$coefficients[,4], function(x) ifelse(x < 0.01, "***", ifelse(x < 0.05, "**", ifelse(x < 0.1, "*", ""))) )
stars_reg3f <- sapply( summary(reg3f)$coefficients[,4], function(x) ifelse(x < 0.01, "***", ifelse(x < 0.05, "**", ifelse(x < 0.1, "*", ""))) )
stars_reg4f <- sapply( summary(reg4f)$coefficients[,4], function(x) ifelse(x < 0.01, "***", ifelse(x < 0.05, "**", ifelse(x < 0.1, "*", ""))) )


df.coef <- data.frame( val  = c( c(coef_reg1f_wglmm), c(coef_reg1f_2_wglmm), c(coef_reg3f_wglmm), c(coef_reg4f_wglmm) ),
                       coef = c(rep( paste0( colnames(coef_reg1f_wglmm), stars_reg1f), each = length(lf)), 
                                rep( paste0( colnames(coef_reg1f_2_wglmm), stars_reg1f_2), each = length(lf)),
                                rep( paste0( colnames(coef_reg3f_wglmm), stars_reg3f), each = length(lf)), 
                                rep( paste0( colnames(coef_reg4f_wglmm), stars_reg4f), each = length(lf)) ),
                       reg  = c(rep("reg1f", prod(dim(coef_reg1f_wglmm))), rep("reg1f_2", prod(dim(coef_reg1f_2_wglmm))),
                                rep("reg3f", prod(dim(coef_reg3f_wglmm))), rep("reg4f", prod(dim(coef_reg4f_wglmm))) )
                       )

df.varre <- data.frame( val  = c( c(varre_reg1f_wglmm), c(varre_reg1f_2_wglmm), c(varre_reg3f_wglmm), c(varre_reg4f_wglmm) ),
                       varre = rep( rep( c("country", "a4b"), each = length(lf) ), times = 4 ),
                       reg  = c(rep("reg1f", prod(dim(varre_reg1f_wglmm))), rep("reg1f_2", prod(dim(varre_reg1f_2_wglmm))),
                                rep("reg3f", prod(dim(varre_reg3f_wglmm))), rep("reg4f", prod(dim(varre_reg4f_wglmm))) )
                      )

df.lme4.coef <- data.frame( val = c( fixef(reg1f), fixef(reg1f_2), fixef(reg3f), fixef(reg4f) ), 
                            coef = c( paste0( names(fixef(reg1f)), stars_reg1f), 
                                      paste0( names(fixef(reg1f_2)), stars_reg1f_2), 
                                      paste0( names(fixef(reg3f)), stars_reg3f), 
                                      paste0( names(fixef(reg4f)), stars_reg4f) ),
                            reg = c( rep("reg1f", length(fixef(reg1f))), rep("reg1f_2", length(fixef(reg1f_2))), rep("reg3f", length(fixef(reg3f))), rep("reg4f", length(fixef(reg4f))) ) 
                            )

df.lme4.varre <- data.frame( val = c( unlist(VarCorr(reg1f)), unlist(VarCorr(reg1f_2)), unlist(VarCorr(reg3f)), unlist(VarCorr(reg4f)) ), 
                            varre = rep( c("country", "a4b"), times = 4 ),
                             reg = c( rep("reg1f", 2), rep("reg1f_2", 2), rep("reg3f", 2), rep("reg4f", 2) )
                            )

library(xtable)
tab <- aggregate(df.coef$val, by = list(df.coef$coef, df.coef$reg), mean)
tab$x <- round(tab$x, digits = 4)
tab2 <- aggregate(df.varre$val, by = list(df.varre$varre, df.varre$reg), mean)
tab2$x <- round(tab2$x, digits = 4)
tab   <- cbind( tab, round( c(fixef(reg1f), fixef(reg1f_2), fixef(reg3f), fixef(reg4f)), digits = 4) )
tab2  <- cbind( tab2, round( c( unlist(VarCorr(reg1f)), unlist(VarCorr(reg1f_2)), unlist(VarCorr(reg3f)), unlist(VarCorr(reg4f)) ), digits = 4))
colnames(tab) <- c("Parameter", "Regression", "Avrg. Estimate MCEM", "Estimate lme4")
colnames(tab2) <- c("Parameter", "Regression", "Avrg. Estimate MCEM", "Estimate lme4")
rownames(tab) <- NULL
rownames(tab2) <- NULL
tab <- rbind(tab)
xtable(tab)

